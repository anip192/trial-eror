<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda &dash; Pussel Records</title>

    <!-- Favicon -->
    <link rel="icon" type="http://pusselrecords.my.id/image/png" href="img/logo/Logo-Icon-01.PNG">
    <link rel="shortcut icon" href="http://pusselrecords.my.id/img/logo/Pussel Records.png">

    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@200..800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="nav/css/header.css">    
    <link rel="stylesheet" href="nav/css/footer.css">
    <link rel="stylesheet" href="css/root.css">
    <link rel="stylesheet" href="css/dplb.css">
</head>
<body>
<?php include 'nav/header.php'; ?>

<div class="container">
<section id="hero-section" class="hero-section">
        <div class="swiper hero-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="http://pusselrecords.my.id/img/carousel/carousel-01.jpeg" class="slide-img" alt="Slide 1">
                </div>
                <div class="swiper-slide">
                    <img src="http://pusselrecords.my.id/img/carousel/carousel-02.jpeg" class="slide-img" alt="Slide 2">
                </div>
                <div class="swiper-slide">
                    <video class="slide-img" muted playsinline>
                        <source src="http://pusselrecords.my.id/img/carousel/carousel-03.MP4" type="video/mp4">
                    </video>
                </div>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
    </div>
    </section>
    
    <!-- Featured Section -->
    <section id="featured-section" class="featured-section">
        <div class="container">
            <div class="featured-header">
                <h2 class="featured-title">Featured Products</h2>
                <div class="slider-nav-buttons">
                    <button class="btn btn-outline-dark btn-sm prev-prod"><i class="bi bi-chevron-left"></i></button>
                    <button class="btn btn-outline-dark btn-sm next-prod"><i class="bi bi-chevron-right"></i></button>
                </div>
            </div>

            <div class="swiper product-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR001"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR001"]["name"]; ?></a></h5>
                                <p class="product-price">Rp 1.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR002"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR002"]["name"]; ?></a></h5>
                                <p class="product-price">Rp 1.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR003"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR003"]["name"]; ?></a></h5>
                                <p class="product-price">Rp288.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR004"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR004"]["name"]; ?></a></h5>
                                <p class="product-price">Rp378.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR005"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR005"]["name"]; ?></a></h5>
                                <p class="product-price">Rp358.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR006"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR006"]["name"]; ?></a></h5>
                                <p class="product-price">Rp358.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR007"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR007"]["name"]; ?></a></h5>
                                <p class="product-price">Rp358.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR008"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR008"]["name"]; ?></a></h5>
                                <p class="product-price">Rp358.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR009"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR009"]["name"]; ?></a></h5>
                                <p class="product-price">Rp358.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="product-card">
                            <div class="product-thumb">
                                <a href="javascript:;" class="trigger-qris-modal">
                                    <img src="<?=  $pd ["PR010"]["image"]; ?>" class="product-img" alt="Product">
                                </a>
                            </div>
                            <div class="product-content">
                                <h5 class="product-name"><a href="javascript:;" class="product-link trigger-qris-modal"><?=  $pd ["PR010"]["name"]; ?></a></h5>
                                <p class="product-price">Rp358.000</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="work-section" id="work">
        <div class="container">
        <h2 class="work-section-title">roster</h2>
    <div class="release-grid">

    <!-- Card 1 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR001</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR001"]["image-cover"] ?>" alt="Album 1" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR001"]["realese_date"] ?></p>
        <h2><?= $lb ["PR001"]["title"] ?></h2>
        <h3><?= $lb ["PR001"]["subtitle"] ?><br><br></h3>
        <a href="roster/PR001/LB-PR001.php" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 2 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR002</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR002"]["image-cover"] ?>" alt="Album 2" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR002"]["realese_date"] ?></p>
        <h2><?= $lb ["PR002"]["title"] ?></h2>
        <h3><?= $lb ["PR002"]["subtitle"] ?></h3>
        <a href="roster/PR002/LB-PR002.php" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 3 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR003</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR003"]["image-cover"] ?>" alt="Album 3" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR003"]["realese_date"] ?></p>
        <h2><?= $lb ["PR003"]["title"] ?></h2>
        <h3><?= $lb ["PR003"]["subtitle"] ?><br><br></h3>
        <a href="roster/PR003/LB-PR003.php" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 4 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR004</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR004"]["image-cover"] ?>" alt="Album 4" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR004"]["realese_date"] ?></p>
        <h2><?= $lb ["PR004"]["title"] ?></h2>
        <h3><?= $lb ["PR004"]["subtitle"] ?></h3>
        <a href="#" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 5 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR005</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR005"]["image-cover"] ?>" alt="Album 5" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR005"]["realese_date"] ?></p>
        <h2><?= $lb ["PR005"]["title"] ?></h2>
        <h3><?= $lb ["PR005"]["subtitle"] ?></h3>
        <a href="#" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 6 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR006</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR006"]["image-cover"] ?>" alt="Album 6" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR006"]["realese_date"] ?></p>
        <h2><?= $lb ["PR006"]["title"] ?></h2>
        <h3><?= $lb ["PR006"]["subtitle"] ?></h3>
        <a href="#" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 7 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR007</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR007"]["image-cover"] ?>" alt="Album 7" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR007"]["realese_date"] ?></p>
        <h2><?= $lb ["PR007"]["title"] ?></h2>
        <h3><?= $lb ["PR007"]["subtitle"] ?></h3>
        <a href="#" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 8 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR008</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR008"]["image-cover"] ?>" alt="Album 8" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR008"]["realese_date"] ?></p>
        <h2><?= $lb ["PR008"]["title"] ?></h2>
        <h3><?= $lb ["PR008"]["subtitle"] ?></h3>
        <a href="#" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 9 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR009</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR009"]["image-cover"] ?>" alt="Album 9" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR009"]["realese_date"] ?></p>
        <h2><?= $lb ["PR009"]["title"] ?></h2>
        <h3><?= $lb ["PR009"]["subtitle"] ?></h3>
        <a href="#" class="swiss-btn">View Details →</a>
      </div>
    </div>

    <!-- Card 9 -->
    <div class="swiss-card">
      <div class="swiss-label">
        <span>PR010</span>
        <span class="dot">●</span>
        <span>RELEASE</span>
      </div>
      <div class="swiss-img">
        <img src="<?= $lb ["PR010"]["image-cover"] ?>" alt="Album 10" />
      </div>
      <div class="swiss-body">
        <p class="swiss-date"><?= $lb ["PR010"]["realese_date"] ?></p>
        <h2><?= $lb ["PR010"]["title"] ?></h2>
        <h3><?= $lb ["PR010"]["subtitle"] ?></h3>
        <a href="#" class="swiss-btn">View Details →</a>
      </div>
    </div>

  </div>
  </div><!-- end .release-grid -->

    <!-- roster Section -->
     <!-- ===== SECTION: WORK ===== -->
    <!-- <section class="work-section" id="work">
        <h2 class="work-section-title">roster Collection</h2>
        <div class="work__container bd-grid">

            <a target="_blank" href="cart/cart.php" alt="checkout" class="work__img">
                <img src="<?=  $lb ["PR001"]["image-cover"]; ?>" alt="">
                <h6 class="work__card__footer">Released : <?=  $lb ["PR001"]["realese_date"]; ?></h6>
                <h4 class="work__card__header"><?=  $lb ["PR001"]["subtitle"]; ?></h4>
                <button class="work__card__button">View Details</button>
            </a>

            <a target="_blank" href="cart/cart.php" alt="checkout" class="work__img">
                <img src="<?=  $lb ["PR002"]["image-cover"]; ?>" alt="">
                <h6 class="work__card__footer">Released : <?=  $lb ["PR002"]["realese_date"]; ?></h6>
                <h4 class="work__card__header"><?=  $lb ["PR002"]["subtitle"]; ?></h4>
                <button class="work__card__button">View Details</button>
            </a>

            <a target="_blank" href="cart/cart.php" alt="checkout" class="work__img">
                <img src="<?=  $lb ["PR003"]["image-cover"]; ?>" alt="">
                <h6 class="work__card__footer">Released : <?=  $lb ["PR003"]["realese_date"]; ?></h6>
                <h4 class="work__card__header"><?=  $lb ["PR003"]["subtitle"]; ?></h4>
                <button class="work__card__button">View Details</button>
            </a>

            <a target="_blank" href="cart/cart.php" alt="checkout" class="work__img">
                <img src="<?=  $lb ["PR004"]["image-cover"]; ?>" alt="">
                <h6 class="work__card__footer">Released : <?=  $lb ["PR004"]["realese_date"]; ?></h6>
                <h4 class="work__card__header"><?=  $lb ["PR004"]["subtitle"]; ?></h4>
                <button class="work__card__button">View Details</button>
            </a>

            <a target="_blank" href="cart/cart.php" alt="checkout" class="work__img">
                <img src="<?=  $lb ["PR005"]["image-cover"]; ?>" alt="">
                <h6 class="work__card__footer">Released : <?=  $lb ["PR005"]["realese_date"]; ?></h6>
                <h4 class="work__card__header"><?=  $lb ["PR005"]["subtitle"]; ?></h4>
                <button class="work__card__button">View Details</button>
            </a>

            <a target="_blank" href="cart/cart.php" alt="checkout" class="work__img">
                <img src="<?=  $lb ["PR006"]["image-cover"]; ?>" alt="">
                <h4 class="work__card__header"><?=  $lb ["PR006"]["subtitle"]; ?></h4>
                <p class="work__card__text"><?=  $lb ["PR006"]["description"]; ?></p>
                <h6 class="work__card__footer">Released : <?=  $lb ["PR006"]["realese_date"]; ?></h6>
                <button class="work__card__button">View Details</button>
            </a>

        </div>
    </section> -->

    <?php include'nav/footer.php' ?>

    <!-- QRIS Modal - TIDAK DIUBAH SAMA SEKALI -->
    <div class="modal fade" id="qrisModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Pembayaran QRIS</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <div id="qris-loading" class="py-4">
                        <div class="spinner-border text-primary" role="status"></div>
                        <p class="mt-2 text-muted">Sedang membuat QRIS...</p>
                    </div>
                    <div id="qris-result" class="d-none">
                        <h3 class="fw-bold" id="qris-total-amount"></h3>
                        <p class="text-muted small mb-3">Tax Fee: Rp<span id="qris-fee"></span></p>
                        <div class="qris-container mx-auto mb-3 p-3 border rounded bg-white" style="display:inline-block;">
                            <div id="qrcode-canvas"></div>
                        </div>
                        <p class="small text-muted">Scan menggunakan GoPay, OVO, Dana, ShopeePay, atau Mobile Banking.</p>
                    </div>
                    <div id="qris-error" class="d-none alert alert-danger">
                        Gagal membuat QRIS. Silakan coba lagi.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-primary" id="check-payment-btn">Sudah Bayar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>