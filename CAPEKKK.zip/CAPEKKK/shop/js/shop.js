document.addEventListener('DOMContentLoaded', function () {

    // ==========================================
    // DATA & STATE
    // ==========================================
    const ITEMS_PER_PAGE = 9;
    let currentPage = 1;

    // Ambil semua product item
    const allProducts = Array.from(document.querySelectorAll('.product-item'));

    // State filter aktif
    let activeFilters = {
        availability: [],
        category: [],
        size: [],
        color: [],
        search: ''
    };

    // ==========================================
    // FILTER LOGIC
    // ==========================================
    function getFilteredProducts() {
        return allProducts.filter(product => {
            const avail  = product.dataset.availability || '';
            const cat    = product.dataset.category    || '';
            const sizes  = (product.dataset.size || '').split(' ');
            const name   = product.querySelector('h4 a')?.innerText?.toLowerCase() || '';

            // Filter availability
            if (activeFilters.availability.length > 0) {
                if (!activeFilters.availability.includes(avail)) return false;
            }

            // Filter category
            if (activeFilters.category.length > 0) {
                if (!activeFilters.category.includes(cat)) return false;
            }

            // Filter size
            if (activeFilters.size.length > 0) {
                const match = activeFilters.size.some(s => sizes.includes(s));
                if (!match) return false;
            }

            // Filter search
            if (activeFilters.search.trim() !== '') {
                if (!name.includes(activeFilters.search.toLowerCase())) return false;
            }

            return true;
        });
    }

    // ==========================================
    // RENDER PRODUK (show/hide + pagination)
    // ==========================================
    function renderProducts() {
        const filtered = getFilteredProducts();
        const total    = filtered.length;
        const start    = (currentPage - 1) * ITEMS_PER_PAGE;
        const end      = start + ITEMS_PER_PAGE;
        const paginated = filtered.slice(start, end);

        // Sembunyikan semua dulu
        allProducts.forEach(p => {
            p.style.display = 'none';
        });

        // Tampilkan yang lolos filter & halaman aktif
        paginated.forEach(p => {
            p.style.display = '';
        });

        // Update result count
        const resultCount = document.getElementById('result-count');
        if (resultCount) {
            resultCount.textContent = `Showing ${total} product${total !== 1 ? 's' : ''}`;
        }

        // Update pagination
        updatePagination(total);
    }

    // ==========================================
    // PAGINATION
    // ==========================================
    function updatePagination(total) {
        const totalPages  = Math.ceil(total / ITEMS_PER_PAGE);
        const prevBtn     = document.getElementById('prev-page');
        const nextBtn     = document.getElementById('next-page');
        const pageNumbers = document.getElementById('page-numbers');
        const paginationInfo = document.getElementById('pagination-info');

        // Info teks
        const start = total === 0 ? 0 : (currentPage - 1) * ITEMS_PER_PAGE + 1;
        const end   = Math.min(currentPage * ITEMS_PER_PAGE, total);

        if (paginationInfo) {
            paginationInfo.innerHTML = `Showing ${start}&ndash;${end} of ${total} products`;
        }

        // Prev / Next
        if (prevBtn) prevBtn.disabled = currentPage <= 1;
        if (nextBtn) nextBtn.disabled = currentPage >= totalPages;

        // Page Numbers
        if (pageNumbers) {
            pageNumbers.innerHTML = '';

            if (totalPages <= 1) return;

            for (let i = 1; i <= totalPages; i++) {
                // Tampilkan halaman pertama, terakhir, dan sekitar aktif
                if (
                    i === 1 ||
                    i === totalPages ||
                    (i >= currentPage - 1 && i <= currentPage + 1)
                ) {
                    const btn = document.createElement('button');
                    btn.className = 'shop-page-num' + (i === currentPage ? ' active' : '');
                    btn.textContent = i;
                    btn.addEventListener('click', () => {
                        currentPage = i;
                        renderProducts();
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    });
                    pageNumbers.appendChild(btn);
                } else if (
                    i === currentPage - 2 ||
                    i === currentPage + 2
                ) {
                    // Dots
                    const dots = document.createElement('span');
                    dots.className = 'shop-page-dots';
                    dots.textContent = '...';
                    pageNumbers.appendChild(dots);
                }
            }
        }
    }

    // Prev button
    document.getElementById('prev-page')?.addEventListener('click', function () {
        if (currentPage > 1) {
            currentPage--;
            renderProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });

    // Next button
    document.getElementById('next-page')?.addEventListener('click', function () {
        const filtered   = getFilteredProducts();
        const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
        if (currentPage < totalPages) {
            currentPage++;
            renderProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });

    // ==========================================
    // CHECKBOX FILTER: Availability, Category, Size, Color
    // ==========================================
    function bindCheckboxFilter(selector, key, countSelector, clearBtnId) {
        const checkboxes = document.querySelectorAll(selector);
        const clearBtn   = document.getElementById(clearBtnId);

        checkboxes.forEach(cb => {
            cb.addEventListener('change', function () {
                if (this.checked) {
                    if (!activeFilters[key].includes(this.value)) {
                        activeFilters[key].push(this.value);
                    }
                } else {
                    activeFilters[key] = activeFilters[key].filter(v => v !== this.value);
                }

                // Update count badge
                const countEl = document.querySelector(countSelector);
                if (countEl) countEl.textContent = activeFilters[key].length;

                // Show/hide clear button
                if (clearBtn) {
                    clearBtn.classList.toggle('d-none', activeFilters[key].length === 0);
                }

                // Update dropdown button style
                const dropdownBtn = cb.closest('.product-filter-dropdown')?.querySelector('.btn.dropdown-toggle');
                if (dropdownBtn) {
                    dropdownBtn.classList.toggle('filter-active', activeFilters[key].length > 0);
                }

                currentPage = 1;
                renderProducts();
            });
        });

        // Clear button
        clearBtn?.addEventListener('click', function () {
            activeFilters[key] = [];
            checkboxes.forEach(cb => cb.checked = false);

            const countEl = document.querySelector(countSelector);
            if (countEl) countEl.textContent = '0';
            this.classList.add('d-none');

            const dropdownBtn = this.closest('.product-filter-dropdown')?.querySelector('.btn.dropdown-toggle');
            if (dropdownBtn) dropdownBtn.classList.remove('filter-active');

            currentPage = 1;
            renderProducts();
        });
    }

    bindCheckboxFilter('.availability-filter', 'availability', '.availability-filter-values', 'clear-availability-btn');
    bindCheckboxFilter('.category-filter',     'category',     '.category-filter-values',     'clear-category-btn');
    bindCheckboxFilter('.size-filter',         'size',         '.size-filter-values',          'clear-size-btn');
    bindCheckboxFilter('.color-filter',        'color',        '.avalaibility-filter-values',  'clear-color-btn');

    // ==========================================
    // SEARCH
    // ==========================================
    const searchInput = document.getElementById('shop-search-input');
    const searchClear = document.getElementById('shop-search-clear');

    searchInput?.addEventListener('input', function () {
        activeFilters.search = this.value.trim();
        searchClear?.classList.toggle('d-none', this.value === '');
        currentPage = 1;
        renderProducts();
    });

    searchClear?.addEventListener('click', function () {
        searchInput.value = '';
        activeFilters.search = '';
        this.classList.add('d-none');
        currentPage = 1;
        renderProducts();
    });

    // ==========================================
    // INIT — render pertama kali
    // ==========================================
    renderProducts();

});
