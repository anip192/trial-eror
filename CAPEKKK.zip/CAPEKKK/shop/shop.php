<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucwords(str_replace('.php', '', basename(__FILE__))); ?> &dash; Pussel Records</title>

    <link rel="icon" type="image/png" href="http://pusselrecords.my.id/img/logo/Logo-Icon-01.PNG">
    <link rel="shortcut icon" href="http://pusselrecords.my.id/img/logo/Logo-Icon-01.PNG">

    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@200..800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="../nav/css/header.css">
    <link rel="stylesheet" href="../nav/css/footer.css">
    <link rel="stylesheet" href="../css/root.css">
    <link rel="stylesheet" href="css/shop.css">
    <script src="shop.js"></script>
</head>
<body>
<?php include '../nav/nav/header.php'; ?>

<div class="shop-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-12">

                <!-- ===== STICKY FILTER BAR ===== -->
                <div class="sticky-product-filter">
                    <div class="col-12">
                        <div class="woocommerce-notices-wrapper"></div>
                    </div>

                    <!-- Topbar: Filter Btn + Count + Search -->
                    <div class="col-12 starcross-shop-topbar">
                        <button class="starcross-product-filter-btn" type="button"
                            data-bs-toggle="collapse" data-bs-target="#filter-bar-wrapper"
                            aria-expanded="false" aria-controls="filter-bar-wrapper">
                            <i class="bi bi-funnel"></i>
                            <span>Filter</span>
                        </button>

                        <p class="woocommerce-result-count" id="result-count">Showing 10 products</p>

                        <!-- Search Bar -->
                        <div class="shop-search-bar">
                            <i class="bi bi-search shop-search-icon"></i>
                            <input type="text" id="shop-search-input" class="shop-search-input"
                                placeholder="Search products...">
                            <button type="button" id="shop-search-clear" class="shop-search-clear d-none">
                                <i class="bi bi-x"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Filter Dropdowns -->
                    <div class="col-md-6 filter-bar-col collapse show" id="filter-bar-wrapper">
                        <div class="filter-bar">

                            <!-- Availability -->
                            <div class="dropdown product-filter-dropdown">
                                <button class="btn dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
                                    Availability
                                </button>
                                <ul class="dropdown-menu">
                                    <li class="clear-availability-wrapper">
                                        <div class="filter-clear-row">
                                            <p class="filter-values">
                                                <span class="availability-filter-values filter-count">0</span> Selected
                                            </p>
                                            <button type="button" id="clear-availability-btn"
                                                class="btn starcross-text-dark filter-clear-btn d-none"
                                                data-key="availability">Clear</button>
                                        </div>
                                    </li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input availability-filter" type="checkbox" value="instock" id="instock">
                                        <label class="filter-check-label" for="instock">In stock</label>
                                    </div></li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input availability-filter" type="checkbox" value="outofstock" id="outofstock">
                                        <label class="filter-check-label" for="outofstock">Out of stock</label>
                                    </div></li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input availability-filter" type="checkbox" value="onbackorder" id="onbackorder">
                                        <label class="filter-check-label" for="onbackorder">On backorder</label>
                                    </div></li>
                                </ul>
                            </div>

                            <!-- Category -->
                            <div class="dropdown product-filter-dropdown">
                                <button class="btn dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
                                    Category
                                </button>
                                <ul class="dropdown-menu">
                                    <li class="clear-category-wrapper">
                                        <div class="filter-clear-row">
                                            <p class="filter-values">
                                                <span class="category-filter-values filter-count">0</span> Selected
                                            </p>
                                            <button id="clear-category-btn"
                                                class="btn starcross-text-dark filter-clear-btn d-none"
                                                data-key="category">Clear</button>
                                        </div>
                                    </li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input category-filter" type="checkbox" value="roster" id="roster">
                                        <label class="filter-check-label" for="roster">Roster</label>
                                    </div></li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input category-filter" type="checkbox" value="accessories" id="accessories">
                                        <label class="filter-check-label" for="accessories">Accessories</label>
                                    </div></li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input category-filter" type="checkbox" value="backpack" id="backpack">
                                        <label class="filter-check-label" for="backpack">Backpack</label>
                                    </div></li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input category-filter" type="checkbox" value="belt" id="belt">
                                        <label class="filter-check-label" for="belt">Belt</label>
                                    </div></li>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input category-filter" type="checkbox" value="collections" id="collections">
                                        <label class="filter-check-label" for="collections">Collections</label>
                                    </div></li>
                                </ul>
                            </div>

                            <!-- Size -->
                            <div class="dropdown product-filter-dropdown">
                                <button class="btn dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
                                    Size
                                </button>
                                <ul class="dropdown-menu">
                                    <li class="clear-size-wrapper">
                                        <div class="filter-clear-row">
                                            <p class="filter-values">
                                                <span class="size-filter-values filter-count">0</span> Selected
                                            </p>
                                            <button id="clear-size-btn"
                                                class="btn starcross-text-dark filter-clear-btn d-none"
                                                data-key="size">Clear</button>
                                        </div>
                                    </li>
                                    <?php
                                    $sizes = ['S','M','L','XL','XXL','29','29S','30','32'];
                                    foreach($sizes as $s):
                                    ?>
                                    <li><div class="filter-check-item">
                                        <input class="form-check-input size-filter" type="checkbox"
                                            value="<?= strtolower($s) ?>" id="size-<?= strtolower($s) ?>">
                                        <label class="filter-check-label" for="size-<?= strtolower($s) ?>"><?= $s ?></label>
                                    </div></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>

                            <!-- Color -->
                            <div class="dropdown product-filter-dropdown">
                                <button class="btn dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
                                    Color
                                </button>
                                <ul class="dropdown-menu">
                                    <li class="clear-color-wrapper">
                                        <div class="filter-clear-row">
                                            <p class="filter-values">
                                                <span class="avalaibility-filter-values filter-count">0</span> Selected
                                            </p>
                                            <button id="clear-color-btn"
                                                class="btn starcross-text-dark filter-clear-btn d-none"
                                                data-key="color">Clear</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- /sticky-filter -->

                <!-- ===== PRODUCT GRID ===== -->
                <div class="row shopwrapper shop-grid">

                    <?php
                    // =============================================
                    // DATA PRODUK — sesuaikan dengan array/DB Anda
                    // =============================================
                    $products = [
                        ['id'=>'PR001','name'=>'Forest Tee','price'=>228000,'image'=>'http://pusselrecords.my.id/img/product/PR001-cover.JPG','image_hover'=>'','category'=>'roster','availability'=>'outofstock','size'=>['S','M','L'],'color'=>[]],
                        ['id'=>'PR002','name'=>'Forest Tee Vol.2','price'=>358000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','category'=>'shirt-man','availability'=>'outofstock','size'=>['M','L','XL'],'color'=>[]],
                        ['id'=>'PR003','name'=>'Classic Tee','price'=>198000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'tshirt','availability'=>'outofstock','size'=>['S','M','L','XL'],'color'=>[]],
                        ['id'=>'PR004','name'=>'Pussel Cap','price'=>288000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'accessories','availability'=>'instock','size'=>[],'color'=>[]],
                        ['id'=>'PR005','name'=>'Pussel Bag','price'=>378000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'backpack','availability'=>'instock','size'=>[],'color'=>[]],
                        ['id'=>'PR006','name'=>'Roster Belt','price'=>358000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'belt','availability'=>'outofstock','size'=>[],'color'=>[]],
                        ['id'=>'PR007','name'=>'Collection Vol.1','price'=>358000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'collections','availability'=>'instock','size'=>['S','M','L'],'color'=>[]],
                        ['id'=>'PR008','name'=>'Collection Vol.2','price'=>358000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'collections','availability'=>'instock','size'=>['S','M','L','XL'],'color'=>[]],
                        ['id'=>'PR009','name'=>'Limited Tee','price'=>358000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'tshirt','availability'=>'outofstock','size'=>['M','L'],'color'=>[]],
                        ['id'=>'PR010','name'=>'Exclusive Set','price'=>358000,'image'=>'http://pusselrecords.my.id/img/product/PR002 FORESTcover.JPG','image_hover'=>'','category'=>'roster','availability'=>'instock','size'=>['S','M','L','XL','XXL'],'color'=>[]],
                    ];

                    // Ganti array $products dengan query DB jika sudah ada koneksi
                    // Contoh: $products = $pd; // dari body.php

                    foreach($products as $product):
                        // Fix nama "-" atau kosong
                        $name  = (!empty($product['name']) && $product['name'] !== '-')
                                 ? htmlspecialchars($product['name'])
                                 : 'Unnamed Product';
                        $price = number_format($product['price'], 0, ',', '.');
                        $img   = htmlspecialchars($product['image']);
                        $imgH  = htmlspecialchars($product['image_hover'] ?? '');
                        $avail = $product['availability'] ?? 'instock';
                        $cat   = $product['category'] ?? '';
                        $sizes = implode(' ', array_map('strtolower', $product['size'] ?? []));
                    ?>

                    <div class="col-lg-3 col-md-4 col-6 product-item"
                         data-availability="<?= $avail ?>"
                         data-category="<?= $cat ?>"
                         data-size="<?= $sizes ?>">
                        <div class="single-product-box">

                            <!-- Gambar -->
                            <div class="product-thumb">
                                <a href="detail.php?id=<?= $product['id'] ?>">
                                    <img src="<?= $img ?>" alt="<?= $name ?>" loading="lazy">
                                </a>

                                <!-- Hover image -->
                                <?php if (!empty($imgH)): ?>
                                <div class="hover-image">
                                    <img src="<?= $imgH ?>" alt="<?= $name ?>" loading="lazy">
                                </div>
                                <?php endif; ?>

                                <!-- Badge availability -->
                                <?php if($avail === 'outofstock'): ?>
                                <span class="stock-badge out">Out of Stock</span>
                                <?php elseif($avail === 'onbackorder'): ?>
                                <span class="stock-badge back">Backorder</span>
                                <?php endif; ?>

                                <!-- Action overlay -->
                                <div class="product_action">
                                    <ul>
                                        <li>
                                            <a href="javascript:;" class="trigger-qris-modal">
                                                Buy Now
                                            </a>
                                        </li>
                                        <li>
                                            <a href="detail.php?id=<?= $product['id'] ?>">
                                                Detail
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <!-- Nama & Harga -->
                            <div class="product-content">
                                <h4>
                                    <a href="detail.php?id=<?= $product['id'] ?>">
                                        <?= $name ?>
                                    </a>
                                </h4>
                                <div class="price-box">
                                    <span class="price">
                                        <span class="woocommerce-Price-amount amount">
                                            <bdi>
                                                <span class="woocommerce-Price-currencySymbol">Rp</span>
                                                <?= $price ?>
                                            </bdi>
                                        </span>
                                    </span>
                                </div>
                            </div>

                        </div>
                    </div>

                    <?php endforeach; ?>

                </div>
                <!-- /product grid -->

                <!-- ===== PAGINATION ===== -->
                <div class="starcross-shop-pagination">
                    <div class="shop-pagination-info">
                        <span id="pagination-info">
                            Showing 1&ndash;<span id="total-visible">10</span> of
                            <span id="total-products">10</span> products
                        </span>
                    </div>
                    <div class="shop-pagination-controls">
                        <button class="shop-page-btn" id="prev-page" disabled>
                            <i class="bi bi-arrow-left"></i>
                        </button>
                        <div class="shop-page-numbers" id="page-numbers"></div>
                        <button class="shop-page-btn" id="next-page">
                            <i class="bi bi-arrow-right"></i>
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php include '../nav/nav/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="js/shop.js"></script>
</body>
</html>