<?php include '../body.php'; ?>

    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="css/header.css">    
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="../css/root.css">
    <link rel="stylesheet" href="../css/dplb.css">
    <script src="script.js"></script>

<footer class="site-footer">
    <div class="container">

        <!-- TOP: Logo + Social -->
        <div class="footer-top">
            <a href="index.php" class="footer-logo">
                <!-- Ganti src dengan logo asli Anda -->
                <div class="logo-box">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z"/>
                    </svg>
                    <div class="logo-text">
                        <span class="logo-sub">DEVHUB</span>
                        <span class="logo-main">ID</span>
                    </div>
                </div>
            </a>

            <div class="footer-social">
                <a href="https://instagram.com" target="_blank" class="social-link" title="Instagram">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                        <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/>
                    </svg>
                </a>
                <a href="https://wa.me/628123456789" target="_blank" class="social-link" title="WhatsApp">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                        <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/>
                    </svg>
                </a>
                <a href="https://github.com" target="_blank" class="social-link" title="GitHub">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512">
                        <path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8z"/>
                    </svg>
                </a>
            </div>
        </div>

        <!-- DIVIDER TIPIS -->
        <div class="footer-divider"></div>

        <!-- MIDDLE: Info 3 Kolom -->
        <div class="footer-info">
            <div class="info-col">
                <a href="../location/location.php">
                <h4>Our Location</h4>
                <p>Jl. Elang Jawa No.5A, Nglarang,<br>Wedomartani, Sleman, Yogyakarta</p>
                <p>Jl. Elang Jawa No.5A, Nglarang,<br>Wedomartani, Sleman, Yogyakarta</p>
                </a>
            </div>
            <div class="info-col">
                <h4>Phone Number :</h4>
                <p><a href="https://wa.me/60175932909" target="_blank">(+60) 17 593 2909</a></p>
                <p><a href="https://wa.me/6285121930348" target="_blank">(+62) 851 2193 0348</a></p>
            </div>
            <div class="info-col">
                <h4>Email :</h4>
                <p><a href="mailto:pusselrecords@gmail.com">pusselrecords@gmail.com</a></p>
            </div>
        </div>

        <!-- DIVIDER TIPIS -->
        <div class="footer-divider"></div>

        <!-- BOTTOM: Copyright -->
        <div class="footer-bottom">
            <p class="footer-tagline">Pussel Records &mdash; PUSH YOUR LIMITS</p>
            <p class="footer-copy">&copy; <?php echo date('Y'); ?>, Pussel Records. All Rights Reserved.</p>
        </div>

    </div>
</footer>

<style>
    /* ============================================
   FOOTER CSS - Monokrom Light Enhanced
   File: footer.css
   ============================================ */

:root {
    --bg-footer:    #fcfcfc;
    --text-dark:    #0f0f0f;
    --text-mid:     #444444;
    --text-light:   #999999;
    --border-color: #e2e2e2;
    --accent:       #0f0f0f;
    --transition:   all 0.25s ease;
}

/* ---- FOOTER UTAMA ---- */
.site-footer {
    background: var(--bg-footer);
    border-top: 1px solid #dee2e6;
    padding-top: 3rem;
    padding-bottom: 1.8rem;
    /* Hapus padding left/right — biarkan .container Bootstrap yang atur */
    width: 100%;
    font-family: 'Poppins', sans-serif;
}

.footer-wrapper {
    /* Samakan dengan .container Bootstrap */
    width: 100%;
    max-width: 1320px;       /* ← max-width Bootstrap .container di xl */
    margin: 0 auto;
    padding-left: 12px;      /* ← sama dengan Bootstrap container padding */
    padding-right: 12px;
    box-sizing: border-box;
}

/* ---- TOP: Logo + Social ---- */
.footer-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.8rem;
}

/* Logo Box */
.footer-logo {
    text-decoration: none;
}

.logo-box {
    display: inline-flex;
    align-items: center;
    gap: 0.6rem;
    background: var(--text-dark);
    color: #fff;
    padding: 0.55rem 1.1rem;
    border-radius: 5px;
    transition: var(--transition);
}

.logo-box:hover {
    background: #333;
}

.logo-box svg {
    width: 26px;
    height: 26px;
    fill: #fff;
}

.logo-text {
    display: flex;
    flex-direction: column;
    line-height: 1.1;
}

.logo-sub {
    font-size: 0.65rem;
    letter-spacing: 3px;
    font-weight: 500;
    opacity: 0.75;
}

.logo-main {
    font-size: 1rem;
    font-weight: 800;
    letter-spacing: 4px;
}

/* Social Icons */
.footer-social {
    display: flex;
    gap: 0.7rem;
    align-items: center;
}

.social-link {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: var(--transition);
    background: #fff;
}

.social-link svg {
    width: 38px;
    height: 38px;
    fill: var(--text-mid);
    transition: var(--transition);
}

.social-link:hover {
    background: var(--text-dark);
    border-color: var(--text-dark);
    transform: translateY(-2px);
}

.social-link:hover svg {
    fill: #fff;
}

/* ---- DIVIDER ---- */
.footer-divider {
    height: 1px;
    background: var(--border-color);
    margin: 0 0 1.8rem 0;
}

/* ---- INFO 3 KOLOM ---- */
.footer-info {
    display: grid;
    grid-template-columns: 1.6fr 1fr 1fr;
    gap: 2.5rem;
    margin-bottom: 1.8rem;
}

.info-col h4 {
    font-size: 0.82rem;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--text-dark);
    margin-bottom: 0.8rem;
    padding-bottom: 0.5rem;
    border-bottom: 1.5px solid var(--text-dark);
    display: inline-block;
}

.info-col p {
    font-size: 0.88rem;
    color: var(--text-mid);
    line-height: 1.75;
    margin-bottom: 0.2rem;
    
}

.info-col a {
    color: var(--text-mid);
    text-decoration: none;
    position: relative;
    transition: var(--transition);
}

.info-col a::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: -1px;
    width: 0;
    height: 1px;
    background: var(--text-dark);
    transition: width 0.3s ease;
}

.info-col a:hover {
    color: var(--text-dark);
}

.info-col a:hover::after {
    width: 100%;
}

/* ---- BOTTOM: Copyright ---- */
.footer-bottom {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.footer-tagline {
    font-size: 0.8rem;
    color: var(--text-light);
    font-style: italic;
}

.footer-copy {
    font-size: 0.8rem;
    color: var(--text-light);
}

/* ============================================
   RESPONSIVE
   ============================================ */
@media (max-width: 768px) {
    .site-footer { padding: 2.5rem 1.8rem 1.5rem; }
    .footer-info { grid-template-columns: 1fr 1fr; gap: 1.8rem; }
}

@media (max-width: 480px) {
    .site-footer { padding: 2rem 1.2rem 1.2rem; }
    .footer-info { grid-template-columns: 1fr; gap: 1.4rem; }
    .footer-top { flex-wrap: wrap; gap: 1rem; }
    .footer-bottom { flex-direction: column; align-items: flex-start; gap: 0.3rem; }
}

</style>