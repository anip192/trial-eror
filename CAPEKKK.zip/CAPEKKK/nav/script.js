document.addEventListener('DOMContentLoaded', function () {
    
    // ==========================================
    // 1. KODE SLIDER (TIDAK DIUBAH)
    // ==========================================

    const heroSwiper = new Swiper('.hero-slider', {
        loop: true,
        autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        effect: 'slide', 
        speed: 1500, 
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
    });

    const productSwiper = new Swiper('.product-slider', {
        autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        slidesPerView: 2, 
        spaceBetween: 20,
        loop: true,
        navigation: {
            nextEl: '.next-prod',
            prevEl: '.prev-prod',
        },
        breakpoints: {
            768: {
                slidesPerView: 3,
                spaceBetween: 30,
                speed: 1500 
            },
            1024: {
                slidesPerView: 4,
                spaceBetween: 30,
                speed: 1500 
            }
        }
    });

    // ==========================================
    // 2. INTEGRASI QRIS DINAMIS (DIPERBAIKI)
    // ==========================================

    // Inisialisasi Modal Bootstrap
    const qrisModalEl = document.getElementById('qrisModal');
    const qrisModal = new bootstrap.Modal(qrisModalEl);

    // Elemen UI
    const loadingView = document.getElementById('qris-loading');
    const resultView = document.getElementById('qris-result');
    const errorView = document.getElementById('qris-error');
    const totalAmountTxt = document.getElementById('qris-total-amount');
    const feeTxt = document.getElementById('qris-fee');
    const canvasContainer = document.getElementById('qrcode-canvas');

    // Event Listener Global (Delegation) untuk klik produk
    document.body.addEventListener('click', function(e) {
        // Cek apakah yang diklik memiliki class 'trigger-qris-modal'
        const trigger = e.target.closest('.trigger-qris-modal');
        
        if (trigger) {
            e.preventDefault();
            
            // Cari elemen harga terdekat dari tombol yang diklik
            const productCard = trigger.closest('.product-card');
            const priceEl = productCard.querySelector('.product-price');
            
            if (priceEl) {
                // Bersihkan teks harga (contoh: "Rp378.000" -> 378000)
                let rawPrice = priceEl.innerText;
                let price = parseInt(rawPrice.replace(/[^0-9]/g, ''), 10);

                if (price > 0) {
                    openQrisModal(price);
                }
            }
        }
    });

    function openQrisModal(amount) {
        // 1. Reset Tampilan Modal
        qrisModal.show();
        loadingView.classList.remove('d-none');
        resultView.classList.add('d-none');
        errorView.classList.add('d-none');
        canvasContainer.innerHTML = ''; 

        // 2. Panggil API PROXY
        const proxyUrl = `api-proxy.php?amount=${amount}`; 

        console.log("Requesting QR to:", proxyUrl);

        fetch(proxyUrl)
            .then(async response => {
                // --- BAGIAN ANTI ERROR ---
                // Kita ambil teks mentah dulu, jangan langsung json()
                const rawText = await response.text();
                
                // Cek status HTTP (200 OK atau bukan)
                if (!response.ok) {
                    throw new Error("Server Error: " + response.status + " | " + rawText);
                }

                // Coba parsing ke JSON
                try {
                    return JSON.parse(rawText);
                } catch (e) {
                    // Jika gagal parsing JSON, berarti server mengirim pesan error teks
                    // Kita lempar teks tersebut agar muncul di layar
                    throw new Error(rawText);
                }
            })
            .then(data => {
                console.log("API Response:", data);

                // Cek status logis dari API
                if ((data.status === true || data.success === true) && data.result) {
                    
                    loadingView.classList.add('d-none');
                    resultView.classList.remove('d-none');
                    
                    // Format Angka ke Rupiah
                    let totalStr = data.result.totalAmount.toString();
                    let feeStr = data.result.fee.toString();

                    totalAmountTxt.innerText = "Rp " + parseInt(totalStr).toLocaleString('id-ID');
                    feeTxt.innerText = parseInt(feeStr).toLocaleString('id-ID');

                    // Generate QR Code
                    new QRCode(canvasContainer, {
                        text: data.result.qrString,
                        width: 200,
                        height: 200,
                        colorDark : "#000000",
                        colorLight : "#ffffff",
                        correctLevel : QRCode.CorrectLevel.H
                    });

                } else {
                    // Jika API membalas JSON tapi statusnya false
                    throw new Error(data.message || data.mess || "Gagal generate QR dari server");
                }
            })
            .catch(err => {
                console.error("Error Detail:", err);
                loadingView.classList.add('d-none');
                errorView.classList.remove('d-none');
                
                // TAMPILKAN PESAN ASLI DARI SERVER DI LAYAR
                // Ini akan mengubah "Unexpected token" menjadi pesan yang bisa dibaca
                // Contoh: "Payment request failed. Invalid Checksum"
                errorView.innerText = "Gagal: " + err.message;
            });
    }

    // Tombol Konfirmasi (Simulasi)
    document.getElementById('check-payment-btn').addEventListener('click', function() {
        alert("Terima kasih! (Simulasi: Cek pembayaran ke server...)");
        qrisModal.hide();
    });

});

document.addEventListener('DOMContentLoaded', () => {

  const cards = document.querySelectorAll('.swiss-card');

  // ── Intersection Observer: animasi fade+slide masuk ──
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target); // hanya sekali
      }
    });
  }, {
    threshold: 0.1,       // trigger saat 10% card terlihat
    rootMargin: '0px 0px -40px 0px'
  });

  // Stagger delay: tiap card muncul bergantian
  cards.forEach((card, index) => {
    card.style.transitionDelay = `${index * 80}ms`;
    observer.observe(card);
  });

  // ── Hover: highlight dot merah ──
  cards.forEach((card) => {
    const dot = card.querySelector('.dot');

    card.addEventListener('mouseenter', () => {
      dot.style.color = '#ff0000';
    });

    card.addEventListener('mouseleave', () => {
      dot.style.color = '#ee0000';
    });
  });

});