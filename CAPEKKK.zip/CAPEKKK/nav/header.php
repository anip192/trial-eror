    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@200..800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/root.css">
    <link rel="stylesheet" href="../css/dplb.css">
    <script src="script.js"></script>

<!-- container-fluid -->
    <div class="header-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="header-top-inner">
                        <div class="free-shipping-text">
                            <a href="../index.php">
                                <img src="http://pusselrecords.my.id/img/logo/Pussel Records-02.png" alt="Logo" class="img-fluid logo-img">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <div class="row header-logo-row">
                <div class="col-12 logo">
                    <a href="#">
                    </a>
                </div>
            </div>

            <div class="header-nav-wrapper">
                <div class="header-left">
                    <a href="../account/account.php" class="header-icon"><i class="bi bi-person"></i></a>
                </div>

                <!-- Nav-bar -->
                <nav class="menu">
                    <ul class="nav nav-menu">
                        <li class="nav-item"><a href="../shop/shop.php" class="nav-link">Shop</a></li>
                        <li class="nav-item"><a href="../location/location.php" class="nav-link">Store Location</a></li>
                        <li class="nav-item"><a href="../roster/roster.php" class="nav-link">roster</a></li>
                    </ul>
                </nav>

                <div class="header-right">
                    <a href="../cart/checkout.php" class="header-icon header-cart">
                        <i class="bi bi-bag"></i>
                        <span class="cart-badge">0</span>
                    </a>
                    <div class="hamburger-menu">
                        <i class="bi bi-list"></i>
                    </div>
                </div>
            </div>
        </div>
    </header>

<style>
/* ============================================
   Header Top
   ============================================ */
.header-top {
    background-color: var(--primary-white);
    color: #fff;
    font-size: 12px;
    padding: 8px 0;
    text-align: center;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.header-top-inner {
    display: flex;
    justify-content: center;
    align-items: center;
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
}

.free-shipping-text p {
    margin-bottom: 0;
}

/* ============================================
   Main Header
   ============================================ */
.header {
    position: sticky;
    top: 0;
    background-color: #ffffff;
    z-index: 1020;
}

.header-logo-row {
    justify-content: center;
}

.logo {
    text-align: center;
}

.logo-img {
    max-width: 250px;
}

.header-nav-wrapper {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 0.75rem;
    padding-bottom: 0.75rem;
    border-top: 1px solid #dee2e6;
    border-bottom: 1px solid #dee2e6;
}

.header-left {
    display: flex;
    gap: 1rem;
}

.header-right {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.header-icon {
    color: #212529;
    font-size: 1.25rem;
    text-decoration: none;
    position: relative;
}

.header-cart {
    position: relative;
}

.cart-badge {
    position: absolute;
    top: 0;
    left: 100%;
    transform: translate(-50%, -50%);
    background-color: #212529;
    color: #fff;
    font-size: 0.6rem;
    border-radius: 50rem;
    padding: 2px 5px;
}

/* Nav-bar */
.menu {
    display: none;
}

@media (min-width: 992px) {
    .menu {
        display: block;
    }
    .hamburger-menu {
        display: none;
    }
}

.nav-menu {
    display: flex;
    justify-content: center;
    gap: 1.5rem;
    list-style: none;
    padding: 0;
    margin: 0;
}

.header .nav-link {
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    color: #212529;
    text-decoration: none;
    transition: color 0.3s;
}

.header .nav-link:hover {
    color: #555;
    text-decoration: underline;
}
</style>