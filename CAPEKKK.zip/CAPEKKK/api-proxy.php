<?php
// File: api-proxy.php
// VERSI MANDIRI: Tidak perlu koneksi ke API Vercel lagi.
// Kita menghitung Checksum QRIS sendiri di server ini.

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$nama = "WARUNK ANTI DEADLINE";
$amount = isset($_GET['amount']) ? $_GET['amount'] : 0;
$fee = $amount * 0.01; // 5% fee (bisa disesuaikan)

// ============================================================
// MASUKKAN QR STRING STATIS TOKO ANDA DI SINI
// ============================================================
$static_qr = "00020101021126610014COM.GO-JEK.WWW01189360091430660303630210G0660303630303UMI51440014ID.CO.QRIS.WWW0215ID10264818658750303UMI5204581253033605802ID5920WARUNK ANTI DEADLINE6009PONTIANAK61057824462070703A0163047EB5";
// ============================================================

if ($amount < 1) {
    echo json_encode(['status' => false, 'message' => 'Nominal tidak valid']);
    exit;
}

try {
    // Hitung total bayar
    $totalAmount = $amount + $fee;
    
    // Panggil fungsi "Magic" konversi QRIS
    $dynamicQR = createDynamicQRIS($static_qr, $totalAmount);
    
    // Kirim respon sukses ke JavaScript
    echo json_encode([
        'status' => true,
        'result' => [
            'amount' => (int)$amount,
            'fee' => (int)$fee,
            'totalAmount' => (int)$totalAmount,
            'qrString' => $dynamicQR
        ]
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

// ============================================================
// FUNGSI LOGIKA QRIS (JANGAN DIUBAH KECUALI PAHAM)
// ============================================================

function createDynamicQRIS($raw_qr, $amount) {
    // 1. Bersihkan string QR (Hapus CRC lama di 4 karakter terakhir)
    $qris = substr($raw_qr, 0, -4); 
    
    // 2. Cek apakah di ujung string ada header CRC "6304" (biasanya ada)
    // Jika ada, kita hapus dulu supaya kita bisa menyisipkan nominal
    if (substr($qris, -4) === '6304') {
        $qris = substr($qris, 0, -4);
    }

    // 3. Format Tag 54 (Transaction Amount)
    // Standar EMVCo: Tag '54' + Panjang Digit + Nominal
    $amount_str = (string)$amount;
    $length = strlen($amount_str);
    $length_str = str_pad($length, 2, '0', STR_PAD_LEFT); // misal "05"
    $tag54 = "54" . $length_str . $amount_str;

    // 4. Susun Ulang String QRIS
    // Logika sederhana: Kita hapus Tag 54 lama (jika ada) lalu tempel yang baru di akhir sebelum CRC
    // (Cara ini 'Hack' tapi valid untuk mayoritas scanner di Indonesia)
    
    // Hapus Tag 54 lama jika ada (agar tidak double) menggunakan Regex sederhana
    // Cari '54' diikuti 2 digit panjang, lalu angka sebanyak panjang tersebut
    // Note: Regex ini basic, tapi cukup untuk project kuliah.
    $qris = preg_replace('/54\d{2}\d+/', '', $qris);

    // Tempel Tag 54 Baru + Header CRC "6304"
    $payload = $qris . $tag54 . "6304";

    // 5. Hitung CRC16 (Checksum)
    $crc = crc16_ccitt_FFFF($payload);

    // 6. Gabungkan semua
    return $payload . $crc;
}

// Algoritma CRC16-CCITT (Standar QRIS Bank Indonesia)
function crc16_ccitt_FFFF($str) {
    $crc = 0xFFFF;
    for ($c = 0; $c < strlen($str); $c++) {
        $crc ^= (ord($str[$c]) << 8);
        for ($i = 0; $i < 8; $i++) {
            if ($crc & 0x8000)
                $crc = ($crc << 1) ^ 0x1021;
            else
                $crc = $crc << 1;
        }
    }
    $hex = dechex($crc & 0xFFFF);
    return strtoupper(str_pad($hex, 4, '0', STR_PAD_LEFT));
}
?>