<html lang="en-US"><!-- head --><head>
		<!-- Page title -->
		<title>DEPRESST!  |  Disaster Records</title>

		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- Shortcut icon -->
		<link rel="shortcut icon" href="https://disasterposse.com/wp-content/uploads/2022/10/IMG_0304.jpeg" type="image/x-icon">

		<meta name="description" content="">
		<link rel="canonical" href="https://disasterposse.com">

		<!-- wp_head -->
<meta name="robots" content="max-image-preview:large">
<link rel="dns-prefetch" href="//capi-automation.s3.us-east-2.amazonaws.com">
<link rel="alternate" type="application/rss+xml" title="Disaster Records » Feed" href="https://disasterposse.com/feed/">
<link rel="alternate" type="application/rss+xml" title="Disaster Records » Comments Feed" href="https://disasterposse.com/comments/feed/">
<link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://disasterposse.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fdisasterposse.com%2Froster%2Fdepresst%2F">
<link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://disasterposse.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fdisasterposse.com%2Froster%2Fdepresst%2F&amp;format=xml">
<style id="wp-img-auto-sizes-contain-inline-css" type="text/css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<link rel="stylesheet" id="sbi_styles-css" href="https://disasterposse.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=6.10.0" type="text/css" media="all">
<style id="wp-emoji-styles-inline-css" type="text/css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id="wp-block-library-inline-css" type="text/css">
:root{--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color);--wp-editor-canvas-background:#ddd;--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,160.5;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}.has-text-align-center{text-align:center}.has-text-align-left{text-align:left}.has-text-align-right{text-align:right}.has-fit-text{white-space:nowrap!important}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-wrap:normal!important}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style*=border-top-color]){border-top-style:solid}html :where([style*=border-right-color]){border-right-style:solid}html :where([style*=border-bottom-color]){border-bottom-style:solid}html :where([style*=border-left-color]){border-left-style:solid}html :where([style*=border-width]){border-style:solid}html :where([style*=border-top-width]){border-top-style:solid}html :where([style*=border-right-width]){border-right-style:solid}html :where([style*=border-bottom-width]){border-bottom-style:solid}html :where([style*=border-left-width]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}

/*# sourceURL=wp-block-library-inline-css */
</style>
<style id="classic-theme-styles-inline-css" type="text/css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<link rel="stylesheet" id="wc-blocks-style-css" href="https://disasterposse.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks.css?ver=wc-10.5.2" type="text/css" media="all">

<style id="global-styles-inline-css" type="text/css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel="stylesheet" id="contact-form-7-css" href="https://disasterposse.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.5" type="text/css" media="all">
<link rel="stylesheet" id="epeken_plugin_styles-css" href="https://disasterposse.com/wp-content/plugins/epeken-all-kurir/class/assets/css/epeken-plugin-style.css?ver=1.1.8.6.14" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-layout-css" href="https://disasterposse.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=10.5.2" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-smallscreen-css" href="https://disasterposse.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=10.5.2" type="text/css" media="only screen and (max-width: 768px)">
<link rel="stylesheet" id="woocommerce-general-css" href="https://disasterposse.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=10.5.2" type="text/css" media="all">
<style id="woocommerce-inline-inline-css" type="text/css">
.woocommerce form .form-row .required { visibility: visible; }
/*# sourceURL=woocommerce-inline-inline-css */
</style>
<link rel="stylesheet" id="moota-payment-gateway-css" href="https://disasterposse.com/wp-content/plugins/moota-wordpress-main/assets/style.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<link rel="stylesheet" id="moota-toastr-css" href="https://disasterposse.com/wp-content/plugins/moota-wordpress-main/assets/css/toastr.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<link rel="stylesheet" id="moota-tailwind-css" href="https://disasterposse.com/wp-content/plugins/moota-wordpress-main/assets/css/style.min.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-pre-orders-main-css-css" href="https://disasterposse.com/wp-content/plugins/pre-orders-for-woocommerce/media/css/main.css?ver=2.3" type="text/css" media="all">
<link rel="stylesheet" id="hint-css" href="https://disasterposse.com/wp-content/plugins/woo-fly-cart/assets/hint/hint.min.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<link rel="stylesheet" id="perfect-scrollbar-css" href="https://disasterposse.com/wp-content/plugins/woo-fly-cart/assets/perfect-scrollbar/css/perfect-scrollbar.min.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<link rel="stylesheet" id="perfect-scrollbar-wpc-css" href="https://disasterposse.com/wp-content/plugins/woo-fly-cart/assets/perfect-scrollbar/css/custom-theme.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<link rel="stylesheet" id="woofc-fonts-css" href="https://disasterposse.com/wp-content/plugins/woo-fly-cart/assets/css/fonts.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<link rel="stylesheet" id="woofc-frontend-css" href="https://disasterposse.com/wp-content/plugins/woo-fly-cart/assets/css/frontend.css?ver=5.9.9" type="text/css" media="all">
<style id="woofc-frontend-inline-css" type="text/css">
.woofc-area.woofc-style-01 .woofc-inner, .woofc-area.woofc-style-03 .woofc-inner, .woofc-area.woofc-style-02 .woofc-area-bot .woofc-action .woofc-action-inner > div a:hover, .woofc-area.woofc-style-04 .woofc-area-bot .woofc-action .woofc-action-inner > div a:hover {
                            background-color: #cc6055;
                        }

                        .woofc-area.woofc-style-01 .woofc-area-bot .woofc-action .woofc-action-inner > div a, .woofc-area.woofc-style-02 .woofc-area-bot .woofc-action .woofc-action-inner > div a, .woofc-area.woofc-style-03 .woofc-area-bot .woofc-action .woofc-action-inner > div a, .woofc-area.woofc-style-04 .woofc-area-bot .woofc-action .woofc-action-inner > div a {
                            outline: none;
                            color: #cc6055;
                        }

                        .woofc-area.woofc-style-02 .woofc-area-bot .woofc-action .woofc-action-inner > div a, .woofc-area.woofc-style-04 .woofc-area-bot .woofc-action .woofc-action-inner > div a {
                            border-color: #cc6055;
                        }

                        .woofc-area.woofc-style-05 .woofc-inner{
                            background-color: #cc6055;
                            background-image: url('');
                            background-size: cover;
                            background-position: center;
                            background-repeat: no-repeat;
                        }
                        
                        .woofc-count span {
                            background-color: #cc6055;
                        }
/*# sourceURL=woofc-frontend-inline-css */
</style>
<link rel="stylesheet" id="bootstrap-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/bootstrap/bootstrap.min.css?ver=4.3.1" type="text/css" media="all">
<link rel="stylesheet" id="animsition-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/animsition/animsition.min.css?ver=4.0.2" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/fonts/font-awesome/font-awesome.min.css?ver=4.7.0" type="text/css" media="all">
<link rel="stylesheet" id="ionicons-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/fonts/ionicons/ionicons.min.css?ver=2.0.0" type="text/css" media="all">
<link rel="stylesheet" id="flaticon-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/fonts/flaticon/flaticon.css?ver=1.0.0" type="text/css" media="all">
<link rel="stylesheet" id="social-icon-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/fonts/social-icon/social-icon.css?ver=1.0.0" type="text/css" media="all">
<link rel="stylesheet" id="awconqueror-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/fonts/awconqueror/awconqueror.css?ver=1.0.0" type="text/css" media="all">
<link rel="stylesheet" id="twcenmt-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/fonts/twcenmt/twcenmt.css?ver=1.0.0" type="text/css" media="all">
<link rel="stylesheet" id="simplebar-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/simplebar/simplebar.css?ver=2.6.1" type="text/css" media="all">
<link rel="stylesheet" id="swiper-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/swiper/swiper.min.css?ver=4.4.2" type="text/css" media="all">
<link rel="stylesheet" id="overide-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/css/overide.css?ver=1.0.0" type="text/css" media="all">
<link rel="stylesheet" id="theme-css" href="https://disasterposse.com/wp-content/themes/dsstr/assets/css/theme.css?ver=1.0.0" type="text/css" media="all">
<link rel="stylesheet" id="acf-global-css" href="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/assets/css/acf-global.css?ver=5.7.12" type="text/css" media="all">
<link rel="stylesheet" id="acf-input-css" href="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/assets/css/acf-input.css?ver=5.7.12" type="text/css" media="all">
<link rel="stylesheet" id="acf-pro-input-css" href="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/pro/assets/css/acf-pro-input.css?ver=5.7.12" type="text/css" media="all">
<link rel="stylesheet" id="select2-css" href="https://disasterposse.com/wp-content/plugins/woocommerce/assets/css/select2.css?ver=10.5.2" type="text/css" media="all">
<link rel="stylesheet" id="acf-datepicker-css" href="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/assets/inc/datepicker/jquery-ui.min.css?ver=1.11.4" type="text/css" media="all">
<link rel="stylesheet" id="acf-timepicker-css" href="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/assets/inc/timepicker/jquery-ui-timepicker-addon.min.css?ver=1.6.1" type="text/css" media="all">
<link rel="stylesheet" id="wp-color-picker-css" href="https://disasterposse.com/wp-admin/css/color-picker.min.css?ver=dda2e2b02de7d9588f4bd91820d996af" type="text/css" media="all">
<script src="https://connect.facebook.net/signals/config/975069446458492?v=2.9.268&amp;r=stable&amp;domain=disasterposse.com&amp;hme=8c09666b801027ec77ae6e3d39d3827f08833acc316174b73d9ec4ab26e1bdc3&amp;ex_m=96%2C188%2C136%2C21%2C68%2C69%2C129%2C64%2C43%2C130%2C73%2C63%2C10%2C144%2C82%2C15%2C95%2C124%2C117%2C71%2C74%2C123%2C141%2C104%2C146%2C7%2C3%2C4%2C6%2C5%2C2%2C83%2C93%2C147%2C152%2C202%2C57%2C168%2C169%2C50%2C240%2C28%2C70%2C214%2C213%2C212%2C30%2C56%2C9%2C59%2C89%2C90%2C91%2C97%2C120%2C29%2C27%2C122%2C119%2C118%2C137%2C72%2C140%2C138%2C139%2C45%2C55%2C113%2C14%2C143%2C40%2C228%2C229%2C227%2C24%2C25%2C26%2C17%2C19%2C39%2C35%2C37%2C36%2C78%2C84%2C88%2C102%2C128%2C131%2C41%2C103%2C22%2C20%2C109%2C65%2C33%2C133%2C132%2C134%2C125%2C23%2C32%2C54%2C101%2C142%2C66%2C16%2C135%2C106%2C77%2C62%2C18%2C31%2C252%2C195%2C182%2C183%2C181%2C255%2C247%2C196%2C99%2C121%2C76%2C111%2C49%2C42%2C44%2C105%2C110%2C116%2C53%2C60%2C115%2C48%2C51%2C47%2C92%2C145%2C0%2C114%2C13%2C112%2C11%2C1%2C52%2C85%2C58%2C61%2C108%2C81%2C80%2C148%2C149%2C86%2C87%2C8%2C94%2C46%2C126%2C79%2C75%2C67%2C107%2C98%2C38%2C127%2C34%2C100%2C12%2C150" async=""></script><script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.10.5.2" id="wc-jquery-blockui-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https://disasterposse.com/cart/","is_cart":"","cart_redirect_after_add":"no"};
//# sourceURL=wc-add-to-cart-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=10.5.2" id="wc-add-to-cart-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.10.5.2" id="wc-js-cookie-js" data-wp-strategy="defer"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%","i18n_password_show":"Show password","i18n_password_hide":"Hide password"};
//# sourceURL=woocommerce-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=10.5.2" id="woocommerce-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/moota-wordpress-main/assets/js/toastr.min.js?ver=dda2e2b02de7d9588f4bd91820d996af" id="moota-taostr-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.13.3" id="jquery-ui-datepicker-js"></script>
<script type="text/javascript" id="jquery-ui-datepicker-js-after">
/* <![CDATA[ */
jQuery(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
//# sourceURL=jquery-ui-datepicker-js-after
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/historyjs/jquery-history.js?ver=dda2e2b02de7d9588f4bd91820d996af" id="historyjs-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/ui/mouse.min.js?ver=1.13.3" id="jquery-ui-mouse-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/ui/sortable.min.js?ver=1.13.3" id="jquery-ui-sortable-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/ui/resizable.min.js?ver=1.13.3" id="jquery-ui-resizable-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/assets/js/acf-input.min.js?ver=5.7.12" id="acf-input-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/pro/assets/js/acf-pro-input.min.js?ver=5.7.12" id="acf-pro-input-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js?ver=4.0.3-wc.10.5.2" id="wc-select2-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/inc/acf/assets/inc/timepicker/jquery-ui-timepicker-addon.min.js?ver=1.6.1" id="acf-timepicker-js"></script>
<link rel="https://api.w.org/" href="https://disasterposse.com/wp-json/"><link rel="alternate" title="JSON" type="application/json" href="https://disasterposse.com/wp-json/wp/v2/roster/1054"><link rel="canonical" href="https://disasterposse.com/roster/depresst/">
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
				<script type="text/javascript">
				!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
					n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
					n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
					t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
					document,'script','https://connect.facebook.net/en_US/fbevents.js');
			</script>
			<!-- WooCommerce Facebook Integration Begin -->
			<script type="text/javascript">

				fbq('init', '975069446458492', {}, {
    "agent": "woocommerce_0-10.5.2-3.5.16"
});

				document.addEventListener( 'DOMContentLoaded', function() {
					// Insert placeholder for events injected when a product is added to the cart through AJAX.
					document.body.insertAdjacentHTML( 'beforeend', '<div class=\"wc-facebook-pixel-event-placeholder\"></div>' );
				}, false );

			</script>
			<!-- WooCommerce Facebook Integration End -->
			<link rel="icon" href="https://disasterposse.com/wp-content/uploads/2022/10/IMG_0304-100x100.jpeg" sizes="32x32">
<link rel="icon" href="https://disasterposse.com/wp-content/uploads/2022/10/IMG_0304-600x600.jpeg" sizes="192x192">
<link rel="apple-touch-icon" href="https://disasterposse.com/wp-content/uploads/2022/10/IMG_0304-600x600.jpeg">
<meta name="msapplication-TileImage" content="https://disasterposse.com/wp-content/uploads/2022/10/IMG_0304-600x600.jpeg">
		<style>
			/*.lazy { background-image: url('https://disasterposse.com/wp-content/uploads/2019/03/fvck.gif'); }*/
			/*.swiper-lazy-preloader { background-image: url('https://disasterposse.com/wp-content/uploads/2019/03/fvck.gif'); }*/
		</style>
	<style id="iris-css">.iris-picker{display:block;position:relative}.iris-picker,.iris-picker *{-moz-box-sizing:content-box;-webkit-box-sizing:content-box;box-sizing:content-box}input+.iris-picker{margin-top:4px}.iris-error{background-color:#ffafaf}.iris-border{border-radius:3px;border:1px solid #aaa;width:200px;background-color:#fff}.iris-picker-inner{position:absolute;top:0;right:0;left:0;bottom:0}.iris-border .iris-picker-inner{top:10px;right:10px;left:10px;bottom:10px}.iris-picker .iris-square-inner{position:absolute;left:0;right:0;top:0;bottom:0}.iris-picker .iris-square,.iris-picker .iris-slider,.iris-picker .iris-square-inner,.iris-picker .iris-palette{border-radius:3px;box-shadow:inset 0 0 5px rgba(0,0,0,.4);height:100%;width:12.5%;float:left;margin-right:5%}.iris-only-strip .iris-slider{width:100%}.iris-picker .iris-square{width:76%;margin-right:10%;position:relative}.iris-only-strip .iris-square{display:none}.iris-picker .iris-square-inner{width:auto;margin:0}.iris-ie-9 .iris-square,.iris-ie-9 .iris-slider,.iris-ie-9 .iris-square-inner,.iris-ie-9 .iris-palette{box-shadow:none;border-radius:0}.iris-ie-9 .iris-square,.iris-ie-9 .iris-slider,.iris-ie-9 .iris-palette{outline:1px solid rgba(0,0,0,.1)}.iris-ie-lt9 .iris-square,.iris-ie-lt9 .iris-slider,.iris-ie-lt9 .iris-square-inner,.iris-ie-lt9 .iris-palette{outline:1px solid #aaa}.iris-ie-lt9 .iris-square .ui-slider-handle{outline:1px solid #aaa;background-color:#fff;-ms-filter:"alpha(Opacity=30)"}.iris-ie-lt9 .iris-square .iris-square-handle{background:0 0;border:3px solid #fff;-ms-filter:"alpha(Opacity=50)"}.iris-picker .iris-strip{margin-right:0;position:relative}.iris-picker .iris-strip .ui-slider-handle{position:absolute;background:0 0;margin:0;right:-3px;left:-3px;border:4px solid #aaa;border-width:4px 3px;width:auto;height:6px;border-radius:4px;box-shadow:0 1px 2px rgba(0,0,0,.2);opacity:.9;z-index:5;cursor:ns-resize}.iris-strip-horiz .iris-strip .ui-slider-handle{right:auto;left:auto;bottom:-3px;top:-3px;height:auto;width:6px;cursor:ew-resize}.iris-strip .ui-slider-handle:before{content:" ";position:absolute;left:-2px;right:-2px;top:-3px;bottom:-3px;border:2px solid #fff;border-radius:3px}.iris-picker .iris-slider-offset{position:absolute;top:11px;left:0;right:0;bottom:-3px;width:auto;height:auto;background:transparent;border:0;border-radius:0}.iris-strip-horiz .iris-slider-offset{top:0;bottom:0;right:11px;left:-3px}.iris-picker .iris-square-handle{background:transparent;border:5px solid #aaa;border-radius:50%;border-color:rgba(128,128,128,.5);box-shadow:none;width:12px;height:12px;position:absolute;left:-10px;top:-10px;cursor:move;opacity:1;z-index:10}.iris-picker .ui-state-focus .iris-square-handle{opacity:.8}.iris-picker .iris-square-handle:hover{border-color:#999}.iris-picker .iris-square-value:focus .iris-square-handle{box-shadow:0 0 2px rgba(0,0,0,.75);opacity:.8}.iris-picker .iris-square-handle:hover::after{border-color:#fff}.iris-picker .iris-square-handle::after{position:absolute;bottom:-4px;right:-4px;left:-4px;top:-4px;border:3px solid #f9f9f9;border-color:rgba(255,255,255,.8);border-radius:50%;content:" "}.iris-picker .iris-square-value{width:8px;height:8px;position:absolute}.iris-ie-lt9 .iris-square-value,.iris-mozilla .iris-square-value{width:1px;height:1px}.iris-palette-container{position:absolute;bottom:0;left:0;margin:0;padding:0}.iris-border .iris-palette-container{left:10px;bottom:10px}.iris-picker .iris-palette{margin:0;cursor:pointer}.iris-square-handle,.ui-slider-handle{border:0;outline:0}</style><script src="https://disasterposse.com/wp-includes/js/wp-emoji-release.min.js?ver=dda2e2b02de7d9588f4bd91820d996af" defer=""></script></head>
	<!-- /head -->

	<!-- body -->
	<body data-rsssl="1" class="wp-singular roster-template-default single single-roster postid-1054 wp-theme-dsstr row m-0 justify-content-md-end theme-dsstr woocommerce-js  pace-done"><div class="pace  pace-inactive"><div class="pace-progress" data-progress-text="100%" data-progress="99" style="transform: translate3d(100%, 0px, 0px);">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
		<!-- #sidebar -->
		<div id="sidebar" class="col-12 col-lg-4 col-xl-2 px-3 px-md-3 py-md-4">
			<a class="home-link" href="https://disasterposse.com">
	<img class="d-block w-100" src="https://disasterposse.com/wp-content/uploads/2022/07/logo-new.svg" alt="Disaster Records Logo">
</a>

<button class="sidebar-toggler d-block d-lg-none" aria-expanded="false"><span class="sidebar-toggler-icon"></span></button>

<div id="sidebar-floating" class="d-flex flex-column p-3 p-lg-0">
	<form role="search" method="get" class="search-form form-search d-block w-100 p-0 m-0 order-lg-1" action="https://disasterposse.com">
		<div class="input-group">
			<input class="form-control search-field rounded-0 border-light" type="search" placeholder="Search…" value="" name="s" title="Search for:">
			<div class="input-group-append">
				<button class="btn btn-light rounded-0" type="submit"><span class="flaticon-search"></span></button>
			</div>
		</div>
	</form>
	
	<ul id="main-menu" class="sidebar-menu row no-gutters m-0 mb-md-4 px-0 py-4"><li id="menu-item-59" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-59 col-12 col-lg-6 "><a title="Home" href="https://disasterposse.com/">Home</a></li>
<li id="menu-item-3251" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3251 col-12 col-lg-6 "><a title="Shop" href="https://disasterposse.com/shop/">Shop</a></li>
<li id="menu-item-71" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-71 col-12 col-lg-6 "><a title="News" href="https://disasterposse.com/news/">News</a></li>
<li id="menu-item-742" class="menu-item menu-item-type-post_type_archive menu-item-object-roster menu-item-742 col-12 col-lg-6 current-menu-item active"><a title="Roster" href="https://disasterposse.com/roster/">Roster</a></li>
<li id="menu-item-84" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-84 col-12 col-lg-6 "><a title="Contact" href="https://disasterposse.com/contact/">Contact</a></li>
<li id="menu-item-81" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-81 col-12 col-lg-6 "><a title="Downloads" href="https://disasterposse.com/downloads/">Downloads</a></li>
<li id="menu-item-80" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-80 col-12 col-lg-6 "><a title="Music" href="https://disasterposse.com/music/">Music</a></li>
<li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79 col-12 col-lg-6 "><a title="FAQ" href="https://disasterposse.com/faq/">FAQ</a></li>
<li id="menu-item-8200" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8200 col-12 col-lg-6 "><a title="Payment" href="https://wa.me/6281313139130">Payment</a></li>
</ul></div>

<div class="d-none d-lg-block mt-md-4">
	<h6 class="m-0 mb-2 text-uppercase">Find Us On</h6>
	<ul class="social-media d-block list-inline m-0 mb-4">
		<li class="list-inline-item">
			<a href="https://www.facebook.com/DSSTR-Records-and-Distribution-1701189030093332/" target="_blank">
				<i class="social-icon-facebook"></i>
			</a>
		</li>
		<li class="list-inline-item">
			<a href="http://twitter.com/dsstrrecs_" target="_blank">
				<i class="social-icon-twitter"></i>
			</a>
		</li>
		<li class="list-inline-item">
			<a href="http://instagram.com/dsstrrecs" target="_blank">
				<i class="social-icon-instagram"></i>
			</a>
		</li>
		<li class="list-inline-item">
			<a href="https://soundcloud.com/disaster-records" target="_blank">
				<i class="social-icon-soundcloud"></i>
			</a>
		</li>
		<li class="list-inline-item">
			<a href="https://www.youtube.com/disasterrecords" target="_blank">
				<i class="social-icon-youtube"></i>
			</a>
		</li>
	</ul>
	<p class="copyright m-0 p-0">© 2016 - 2026 Disaster Records.</p>
</div>		</div>
		<!-- /#sidebar -->
		<!-- #wrapper -->
		<div id="wrapper" class="animsitionxxx col-12 col-lg-8 col-xl-10 px-3 p-md-0" data-function="Init" data-loader-xx="https://disasterposse.com/wp-content/uploads/2019/03/fvck.gif">
<div id="page" class="row p-2 p-md-4">
	<div class="col-12"><h2 class="title">DEPRESST!</h2></div>
	<div class="col-12 col-md-6">
		<img class="d-block w-100" src="https://disasterposse.com/wp-content/uploads/2019/04/BP-1.jpg">
	</div>
	<div class="col-12 col-md-6 page-content page-size text-dark">
		<p><strong>Bio:</strong></p>
<div>Depresst! is a collective band from Balikpapan, East Borneo. Crust rooted in the conviction that all forms of musical expression have something to offer. Formed in 2015 by Ardato Bonano, Arif Satria, Jali and Ryan Gantara. With a bit of HC/Punk, Raw and beats a dark on the guitar sounds. Depresst! Spent 1 years to recorded EP album Blackness Of Authority that built a strong buzz in the underground scene. Think Discharge combine Amebix . And add in some blackned sound too. Then you’re getting close to the Blackness Of Authority.</div>
<p><strong>Origin:</strong></p>
<p>Balikpapan</p>
<p><strong>Genres:</strong></p>
<p>Dark Hardcore / Metal</p>
<p><strong>Members:</strong></p>
<ul>
<li>
<div>Ardato Bonano – Vokal</div>
<div></div>
</li>
<li>
<div>Ryan Gantara – Drum</div>
<div></div>
</li>
<li>
<div>Jali – Gitar</div>
<div></div>
</li>
<li>
<div>Arif Satria – Bass</div>
</li>
</ul>
<p><strong>Years Active:</strong></p>
<p>2015 – now</p>
<p><strong>Contact:</strong></p>
<ul>
<li>
<div><a href="mailto:depresst.band@gmail.com" target="_blank" rel="noopener noreferrer">depresst.band@gmail.com</a></div>
<div></div>
</li>
<li>+6289-7124-4348</li>
</ul>
		<h6 class="m-0 mb-2 mt-4 mt-md-5 text-uppercase font-title">Find Them On</h6>
		<ul class="social-media d-block list-inline m-0 p-0">
			<li class="list-inline-item">
				<a href="https://www.instagram.com/depresstband/" target="_blank">Instagram</a>
			</li>
		</ul>
	</div>
	<!-- #related-posts -->
	<div class="col-12 mt-4">
		<div id="related-posts" class="row products">
			<div class="col-12"><h2 class="title">Catalog</h2></div>
<div class="col-6 col-md-4 col-xl-3 product">
	<a class="product-image d-block" href="https://disasterposse.com/product/depresst-blackness-of-authority/" title="DEPRESST! – BLACKNESS OF AUTHORITY">
		<img class="w-100 lazy loaded" src="https://disasterposse.com/wp-content/uploads/2019/04/CS1-600x600.jpg" alt="DEPRESST! – BLACKNESS OF AUTHORITY" style="">
		<img class="w-100 product-hover lazy loaded" src="https://disasterposse.com/wp-content/uploads/2019/04/CS2-600x600.jpg" alt="DEPRESST! – BLACKNESS OF AUTHORITY" style="">
	</a>
	<div class="product-content text-right">
		<a class="d-block product-title text-uppercase mt-2" href="https://disasterposse.com/product/depresst-blackness-of-authority/" title="DEPRESST! – BLACKNESS OF AUTHORITY">DEPRESST! – BLACKNESS OF AUTHORITY</a>
		<span class="product-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">Rp</span>55,000</bdi></span></span>
	</div>
</div>		</div>
	</div>
	<!-- /#related-posts -->
</div>
			</div>
		
		<!-- /#wrapper -->
		<!-- footer -->
		<footer class="d-block d-lg-none py-3 px-2 w-100 text-center">
			<h6 class="m-0 mb-2 text-uppercase">Find Us On</h6>
			<ul class="social-media d-block list-inline m-0 mb-3">
				<li class="list-inline-item">
					<a href="https://www.facebook.com/DSSTR-Records-and-Distribution-1701189030093332/" target="_blank">
						<i class="social-icon-facebook"></i>
					</a>
				</li>
				<li class="list-inline-item">
					<a href="http://twitter.com/dsstrrecs_" target="_blank">
						<i class="social-icon-twitter"></i>
					</a>
				</li>
				<li class="list-inline-item">
					<a href="http://instagram.com/dsstrrecs" target="_blank">
						<i class="social-icon-instagram"></i>
					</a>
				</li>
				<li class="list-inline-item">
					<a href="https://soundcloud.com/disaster-records" target="_blank">
						<i class="social-icon-soundcloud"></i>
					</a>
				</li>
				<li class="list-inline-item">
					<a href="https://www.youtube.com/disasterrecords" target="_blank">
						<i class="social-icon-youtube"></i>
					</a>
				</li>
			</ul>
			<p class="copyright m-0 p-0">© 2016 - 2026 Disaster Records.</p>
		</footer>
		<!-- /footer -->
		<!-- #order-modal -->
		<div class="modal fade" id="order-modal" tabindex="-1" role="dialog" aria-labelledby="order-modal" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
				<div class="modal-content rounded-0 border">
					<div class="modal-header px-3 py-2 border-bottom">
						<h2 class="modal-title title text-uppercase w-100 border-0 m-0 p-0" id="order-modal-label">Order Form</h2>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span class="flaticon-times"></span>
						</button>
					</div>
					<div class="modal-body p-3">
								
		<form id="order-form" class="contact-form acf-form" action="" method="post" autocomplete="false">
			
			<div id="acf-form-data" class="acf-hidden">
		<input id="_acf_screen" name="_acf_screen" value="acf_form" type="hidden">
<input id="_acf_post_id" name="_acf_post_id" value="new_post" type="hidden">
<input id="_acf_validation" name="_acf_validation" value="1" type="hidden">
<input id="_acf_form" name="_acf_form" value="elQ1eUUyTjFCTHMvTXV2RCtoUUNhSW9Tb0trNzFNeldaOXA5bCtDbm9vZkhuT2VKM2J1YlNTSk5zbS82SEtrcXlkSW5CNm5zSko2ai81MGRuRFhEVmVoZ0FqYTQ0V25xbG1ma3NpNjVGbDFuQzRGdjZodVBnbnNUamxXdWdTU1ZCK1NYOEhHZ24yUTVCYjRuaWQvcTlmanJaK2x3Ry9EMVl6UHcrMDBkc3NQRk9UU3FNSHR6c3ZFYThZOTVpa3JvSTlrMzJaSHFOdGpXSzVRc3lvVDNUbE5PSTRmUGRsRzF6RStLcXZJNFJhYUt5Vmt2SWprOFNnbjNQdHRFZEswVDNWUjkvTEdpNmxjTUlZMjRFM09BYWgzMUw4SWJRUGd3YXhzZTgrNTVnZUJDcFRKQURhK2VrVS9MVW1zcGhHKzN5L21ibi9SU1JxdWg0MkJyVlQwN1diSzdyZ0V1bnVFaUt0cUVmMmtIT1VvR2UwSEwxRW8rNXgvcXNGWVg1Sjk0c004NHdkVVZOMEpyMXUrZWlaTEUrOUJxUzBpRDhUNTQxRy84a1BhVGd0NjQrZm8ydHptVDRhRm1HbDM5WXg5Y1QwRzd4STVUbGkrWkNjZ09aQzdPUVphWWRLaG0vVnAxUE9rYkVaN3NDaEZqYlhVeTF6MVRFUGxrT3YyY0NLa3hvUnRXRXpMUlVPTFBFSGRiajJEbW1mcDJFbkxjT3hPMEVYcHUzc0VDREpOYktIbm5FTThxRU9kYWFKNVdPdllpbEIvZVA2dE4wcEZHSXVRMm1HOExxcnFsNmxLTzM0Yk83UUU5WkhsOHFwditEQWZCa3JLRytRTzR6SE9BU3VMYk1tdXdpQWxsWXZRZUlUZXQwY0dJaEtuekREN0VGdjVqdU85Y2s1MzIxTTVQTUlUNHZvdzVwOEYxWWQ0QzBJTGpvOHl2TE5rdEEzVFd5UXljMVF6ak9nYjNJTnQ1TzF1ZnlENlZNUkpGaml4UUNqSTBxTWZxZFJlOCtqU3R1enVZTzNwN05CcmlNbHkyQU1xWFpIWWZsSzh3MFEvdFVVbTRpQUt3STNvZGJ5cWxRTllhOGRtZlE5aWh2R1pQT0ZpL3JxQlgwVEQ0L0VYbWJ6aWkxYkJweXdoT0UvRjBqQlRBNVVpeDMzUTNDM0YzQUhnUGhjRXNOMUNRbjdnN29LNkhYaW9NTHlYZDljdzFJZHJScm9WZFhSdVUwVGN3dGlSWThMNW41Vjc0Ty9ucUZNdEtHbndtbUFHNmtHQzNIcFlBYlVpVjFXYjdSRkFCT1ZXdmhJaU1WVkJZUjBRTFl3MWpsRXhFN2Z0Ti91a2VtQi8wSDVUemllVXczbGxTSmdJTi9aVEszbWk4YTBQSzY5SlcybGZsbytFMVZodThtT1FUeXR0NmRsc3c2d2craDNvTjk2Q2xNZzMyc0JDR3lTanYxeTFLcGI2TUFmOUdxb2k5UDdhREFhNzhtQWpnTUZhNWd6Q28xUmdSYTAxbFFKaGJBTXlSSWZEMmg1bDRJWndxTGlHNGduY0NOZVF2MGVRYjZONEt2VFdzRTl4Q3lFZitFRmFCUUFwR29LSGJhOHpFNUdvVWgrTzhWNnZ4ZEUzOWhwbVFCc2hsUDlIYkVFRWtlN3VVL1ViSW9NQWUzREk2ZkVLUElzcG9sbW52RVE1R2NETUg4ZjQ4NUxXcFhSajh5bDZWQS9oZlh1QTVRUm9pUEZ3STlra1VwZVhFUk4vNEUxN0lnKytKUzJHb2ltS2Q5QzVFYmtJWW1MTzJUTGFxZnB3U2ZKZitaRW9CM1NvYmpOaCtQTVRTQVBjdDhSS28vRnFVVUZ6UyszVVpTWlNZQTJ1R3dEN0VWSk5FZ0hsS3NpRy8yQy9OQzQxYnVBblNFU2MxbElPNDh5c1Y0dkdOY0JVZUI1MGlCRy9iZzdPczBFS3RaZUFNdlZONGROVDNUMkpjRFdiSkNRWUlYOXBNTVNrZlJaM0gyR2s3LzhGNU1LVEVrN2QrKzhvTThvYWlwbnJ5WEwrRWhxVXliRndjVU5tcU1ISTRhQ1ZEWUpCeTg1eUZVTkZDNFlxTmp3Y2RnSTNzR3FvZ2ZBQkhITi9kb0lUM0p0V3IzdGNkUzFJek1EeGlrUHIwV2NjUGFiRkhaU0VLbldNNDJJWXR6WkdFdE9lZ1Fjams4SGNhaWEwRWswQXNxL0Y2NkhsT1hWcUtUY2U0WUZYWWNGYTh4dFFoY2RiQUhXblZUdzFHUWp0SWx6YWFqcWg1dnhTMUNLOVlqbFRLeFppVS9aM0F3MGlKaUMwMEFVZTZaN0xrcHBObDNGRmlhYXIrWGdXRUJOd3d1U1ltMzhKMG55WkV5QW5wek11aFFqSWNzNXdkTmZNVnVQTkhKUVMzbGY3UWM2TWJZd3VBelVGZ2o5b2dvRDV4aEZoTWNObWovN0FPVytKUGxJcTJjZVNKeVoyK1FtWXVTcklZaTl4dnQ3WTEvZnRER2RhQTBnPT06Oi60cjFaE0XZDtd3+DB7krc=" type="hidden">
<input id="_acf_nonce" name="_acf_nonce" value="31e2a38028" type="hidden">
<input id="_acf_changed" name="_acf_changed" value="0" type="hidden">
	</div>
			
		<div class="acf-fields acf-form-fields -top">
			<div class="acf-field acf-field-text acf-field-5c9365ccd468b is-required" style="width:100%;" data-name="name" data-type="text" data-key="field_5c9365ccd468b" data-required="1" data-width="100">
<div class="acf-label">
<label for="acf-field_5c9365ccd468b">Name <span class="acf-required">*</span></label></div>
<div class="acf-input">
<div class="acf-input-wrap"><input type="text" id="acf-field_5c9365ccd468b" name="acf[field_5c9365ccd468b]" required="required"></div></div>
</div>
<div class="acf-field acf-field-email acf-field-5c9365ccd4699 is-required" style="width:50%;" data-name="email" data-type="email" data-key="field_5c9365ccd4699" data-required="1" data-width="50">
<div class="acf-label">
<label for="acf-field_5c9365ccd4699">Email <span class="acf-required">*</span></label></div>
<div class="acf-input">
<div class="acf-input-wrap"><input type="email" id="acf-field_5c9365ccd4699" name="acf[field_5c9365ccd4699]" required="required"></div></div>
</div>
<div class="acf-field acf-field-text acf-field-5c9366103e518 is-required" style="width:50%;" data-name="phone_number" data-type="text" data-key="field_5c9366103e518" data-required="1" data-width="50">
<div class="acf-label">
<label for="acf-field_5c9366103e518">Phone Number <span class="acf-required">*</span></label></div>
<div class="acf-input">
<div class="acf-input-wrap"><input type="text" id="acf-field_5c9366103e518" name="acf[field_5c9366103e518]" required="required"></div></div>
</div>
<div class="acf-field acf-field-textarea acf-field-5c9365ec3e517 is-required" data-name="address" data-type="textarea" data-key="field_5c9365ec3e517" data-required="1">
<div class="acf-label">
<label for="acf-field_5c9365ec3e517">Address <span class="acf-required">*</span></label></div>
<div class="acf-input">
<textarea id="acf-field_5c9365ec3e517" name="acf[field_5c9365ec3e517]" rows="5" required="required"></textarea></div>
</div>
<div class="acf-field acf-field-text acf-field-5c9378bb87d11 is-required order-form-name" style="width:35%;" data-name="product" data-type="text" data-key="field_5c9378bb87d11" data-required="1" data-width="35">
<div class="acf-label">
<label for="acf-field_5c9378bb87d11">Product <span class="acf-required">*</span></label></div>
<div class="acf-input">
<div class="acf-input-wrap"><input type="text" id="acf-field_5c9378bb87d11" name="acf[field_5c9378bb87d11]" required="required"></div></div>
</div>
<div class="acf-field acf-field-text acf-field-5c9365ccd46cb is-required order-form-code" style="width:35%;" data-name="code" data-type="text" data-key="field_5c9365ccd46cb" data-required="1" data-width="35">
<div class="acf-label">
<label for="acf-field_5c9365ccd46cb">Code <span class="acf-required">*</span></label></div>
<div class="acf-input">
<div class="acf-input-wrap"><input type="text" id="acf-field_5c9365ccd46cb" name="acf[field_5c9365ccd46cb]" required="required"></div></div>
</div>
<div class="acf-field acf-field-number acf-field-5c93663e3e519 is-required" style="width:30%;" data-name="qty" data-type="number" data-key="field_5c93663e3e519" data-required="1" data-width="30">
<div class="acf-label">
<label for="acf-field_5c93663e3e519">Qty <span class="acf-required">*</span></label></div>
<div class="acf-input">
<div class="acf-input-wrap"><input type="number" id="acf-field_5c93663e3e519" name="acf[field_5c93663e3e519]" value="1" min="1" step="any" required="required"></div></div>
</div>
<div class="acf-field acf-field-text acf-field--validate-email" style="display:none !important;" data-name="_validate_email" data-type="text" data-key="_validate_email">
<div class="acf-label">
<label for="acf-_validate_email">Validate Email</label></div>
<div class="acf-input">
<div class="acf-input-wrap"><input type="text" id="acf-_validate_email" name="acf[_validate_email]"></div></div>
</div>
<input type="hidden" name="acf[order_form]" value="1"><input class="product-price" type="hidden" name="acf[product_price]" value="">		</div>
		
				
		<div class="acf-form-submit">
			
			<div class="acf-field-submit d-flex justify-content-between"><a href="#" class="btn btn-danger rounded-0 px-4 py-2 text-uppercase" data-dismiss="modal" aria-label="Close">Cancel</a><input type="submit" id="form-submit" class="btn btn-dark rounded-0 px-4 py-2 text-uppercase" value="Order"></div>			<div class="d-block w-100 text-center form-loader"><span class="acf-spinner"></span></div>			
		</div>
		
		</form>
							</div>
				</div>
			</div>
		</div>
		<!-- /#order-modal -->

		<!-- wp_footer -->
		<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/dsstr/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<div id="woofc-area" class="woofc-area woofc-position-05 woofc-effect-05 woofc-slide-yes woofc-rounded-no woofc-style-01"><div class="woofc-inner woofc-cart-area" data-nonce="9d3e1b69cc"><div class="woofc-area-top"><span class="woofc-area-heading">Shopping cart<span class="woofc-area-count">0</span></span><div class="woofc-close hint--left" aria-label="Close"><i class="woofc-icon-icon10"></i></div></div><!-- woofc-area-top --><div class="woofc-area-mid woofc-items ps-container ps-theme-wpc" data-ps-id="582c0c7d-7c58-04fd-cbc1-8996d59ed914"><div class="woofc-no-item">There are no products in the cart!</div><div class="ps-scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps-scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps-scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div><!-- woofc-area-mid --><div class="woofc-area-bot"><div class="woofc-continue"><span class="woofc-continue-url" data-url="">Continue shopping</span></div></div><!-- woofc-area-bot --></div></div><div id="woofc-count" class="woofc-count woofc-count-0 woofc-count-bottom-left woofc-count-shake" data-count="0"><i class="woofc-icon-cart7"></i><span id="woofc-count-number" class="woofc-count-number">0</span></div><div class="woofc-overlay"></div><!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "https://disasterposse.com/wp-admin/admin-ajax.php";
</script>
			<!-- Facebook Pixel Code -->
			<noscript>
				<img
					height="1"
					width="1"
					style="display:none"
					alt="fbpx"
					src="https://www.facebook.com/tr?id=975069446458492&ev=PageView&noscript=1"
				/>
			</noscript>
			<!-- End Facebook Pixel Code -->
				<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.5" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-before">
/* <![CDATA[ */
var wpcf7 = {
    "api": {
        "root": "https:\/\/disasterposse.com\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    }
};
//# sourceURL=contact-form-7-js-before
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.5" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/epeken-all-kurir/assets/jquery.cookie.js?ver=dda2e2b02de7d9588f4bd91820d996af" id="jquery-cookie-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/pre-orders-for-woocommerce/media/js/date-picker.js?ver=2.3" id="preorders-field-date-js-js"></script>
<script type="text/javascript" id="preorders-main-js-js-extra">
/* <![CDATA[ */
var DBData = {"default_add_to_cart_text":"Add to cart","preorders_add_to_cart_text":"Pre Order Now!"};
//# sourceURL=preorders-main-js-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/pre-orders-for-woocommerce/media/js/main.js?ver=2.3" id="preorders-main-js-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woo-fly-cart/assets/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js?ver=5.9.9" id="perfect-scrollbar-js"></script>
<script type="text/javascript" id="wc-cart-fragments-js-extra">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_4301982f11929c2fbfa22a2ebec680c6","fragment_name":"wc_fragments_4301982f11929c2fbfa22a2ebec680c6","request_timeout":"5000"};
//# sourceURL=wc-cart-fragments-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=10.5.2" id="wc-cart-fragments-js" data-wp-strategy="defer"></script>
<script type="text/javascript" id="woofc-frontend-js-extra">
/* <![CDATA[ */
var woofc_vars = {"wc_ajax_url":"/?wc-ajax=%%endpoint%%","nonce":"9d3e1b69cc","scrollbar":"yes","auto_show":"yes","auto_show_normal":"yes","show_cart":"no","show_checkout":"no","delay":"300","undo_remove":"yes","confirm_remove":"no","instant_checkout":"no","instant_checkout_open":"no","confirm_empty":"no","confirm_empty_text":"Do you want to empty the cart?","confirm_remove_text":"Do you want to remove this item?","undo_remove_text":"Undo?","removed_text":"%s was removed.","manual_show":"","reload":"no","suggested_carousel":"1","save_for_later_carousel":"1","upsell_funnel_carousel":"1","slick_params":"{\"slidesToShow\":1,\"slidesToScroll\":1,\"dots\":true,\"arrows\":false,\"autoplay\":false,\"autoplaySpeed\":3000,\"rtl\":false}","is_cart":"","is_checkout":"","cart_url":"","hide_count_empty":"no","wc_checkout_js":"https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/frontend/checkout.js"};
//# sourceURL=woofc-frontend-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woo-fly-cart/assets/js/frontend.js?ver=5.9.9" id="woofc-frontend-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/animsition/animsition.min.js?ver=4.0.2" id="animsition-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/pace/pace.min.js?ver=1.0.0" id="pace-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/bootstrap/popper.min.js?ver=1.14.7" id="popper-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/bootstrap/bootstrap.min.js?ver=4.3.1" id="bootstrap-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/lazy/jquery.lazy.min.js?ver=1.7.9" id="lazy-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/simplebar/simplebar.js?ver=2.6.1" id="simplebar-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/swiper/swiper.min.js?ver=4.4.2" id="swiper-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.min.js?ver=1.7.21-wc.10.5.2" id="wc-zoom-js" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/libs/notify/bootstrap-notify.js?ver=3.1.5" id="notify-js"></script>
<script type="text/javascript" id="main-js-extra">
/* <![CDATA[ */
var dr_ajax = {"ajax_url":"https://disasterposse.com/wp-admin/admin-ajax.php"};
//# sourceURL=main-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/themes/dsstr/assets/js/main.js?ver=1.0" id="main-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=10.5.2" id="sourcebuster-js-js"></script>
<script type="text/javascript" id="wc-order-attribution-js-extra">
/* <![CDATA[ */
var wc_order_attribution = {"params":{"lifetime":1.0e-5,"session":30,"base64":false,"ajaxurl":"https://disasterposse.com/wp-admin/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":true},"fields":{"source_type":"current.typ","referrer":"current_add.rf","utm_campaign":"current.cmp","utm_source":"current.src","utm_medium":"current.mdm","utm_content":"current.cnt","utm_id":"current.id","utm_term":"current.trm","utm_source_platform":"current.plt","utm_creative_format":"current.fmt","utm_marketing_tactic":"current.tct","session_entry":"current_add.ep","session_start_time":"current_add.fd","session_pages":"session.pgs","session_count":"udata.vst","user_agent":"udata.uag"}};
//# sourceURL=wc-order-attribution-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=10.5.2" id="wc-order-attribution-js"></script>
<script type="text/javascript" src="https://capi-automation.s3.us-east-2.amazonaws.com/public/client_js/capiParamBuilder/clientParamBuilder.bundle.js" id="facebook-capi-param-builder-js"></script>
<script type="text/javascript" id="facebook-capi-param-builder-js-after">
/* <![CDATA[ */
if (typeof clientParamBuilder !== "undefined") {
					clientParamBuilder.processAndCollectAllParams(window.location.href);
				}
//# sourceURL=facebook-capi-param-builder-js-after
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/ui/draggable.min.js?ver=1.13.3" id="jquery-ui-draggable-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/ui/slider.min.js?ver=1.13.3" id="jquery-ui-slider-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-includes/js/jquery/jquery.ui.touch-punch.js?ver=0.2.2" id="jquery-touch-punch-js"></script>
<script type="text/javascript" src="https://disasterposse.com/wp-admin/js/iris.min.js?ver=1.0.7" id="iris-js"></script>
<script type="text/javascript" id="wp-color-picker-js-extra">
/* <![CDATA[ */
var wpColorPickerL10n = {"clear":"Clear","defaultString":"Default","pick":"Select Color","current":"Current Color"};
//# sourceURL=wp-color-picker-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://disasterposse.com/wp-admin/js/color-picker.min.js?ver=dda2e2b02de7d9588f4bd91820d996af" id="wp-color-picker-js"></script>
<script type="text/javascript" id="facebook-for-woocommerce-inline-js-after">
/* <![CDATA[ */
/* WooCommerce Facebook Integration Event Tracking */
fbq('set', 'agent', 'woocommerce_0-10.5.2-3.5.16', '975069446458492');
fbq('track', 'PageView', {
    "source": "woocommerce_0",
    "version": "10.5.2",
    "pluginVersion": "3.5.16",
    "user_data": {}
}, {
    "eventID": "091a994b-9eb1-4bf3-96d0-1ce8c82b6c2e"
});
//# sourceURL=facebook-for-woocommerce-inline-js-after
/* ]]> */
</script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://disasterposse.com/wp-includes/js/wp-emoji-release.min.js?ver=dda2e2b02de7d9588f4bd91820d996af"}}
</script>
<script type="module">
/* <![CDATA[ */
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://disasterposse.com/wp-includes/js/wp-emoji-loader.min.js
/* ]]> */
</script>
<script type="text/javascript">
acf.data = {"screen":"acf_form","post_id":"new_post","nonce":"2367a33ae1","admin_url":"https:\/\/disasterposse.com\/wp-admin\/","ajaxurl":"https:\/\/disasterposse.com\/wp-admin\/admin-ajax.php","validation":true,"wp_version":"6.9.1","acf_version":"5.7.12","browser":"chrome","locale":"en_US","rtl":false,"mimeTypeIcon":"https:\/\/disasterposse.com\/wp-includes\/images\/media\/default.png","mimeTypes":{"jpg|jpeg|jpe":"image\/jpeg","gif":"image\/gif","png":"image\/png","bmp":"image\/bmp","tiff|tif":"image\/tiff","webp":"image\/webp","avif":"image\/avif","ico":"image\/x-icon","heic":"image\/heic","heif":"image\/heif","heics":"image\/heic-sequence","heifs":"image\/heif-sequence","asf|asx":"video\/x-ms-asf","wmv":"video\/x-ms-wmv","wmx":"video\/x-ms-wmx","wm":"video\/x-ms-wm","avi":"video\/avi","divx":"video\/divx","flv":"video\/x-flv","mov|qt":"video\/quicktime","mpeg|mpg|mpe":"video\/mpeg","mp4|m4v":"video\/mp4","ogv":"video\/ogg","webm":"video\/webm","mkv":"video\/x-matroska","3gp|3gpp":"video\/3gpp","3g2|3gp2":"video\/3gpp2","txt|asc|c|cc|h|srt":"text\/plain","csv":"text\/csv","tsv":"text\/tab-separated-values","ics":"text\/calendar","rtx":"text\/richtext","css":"text\/css","vtt":"text\/vtt","dfxp":"application\/ttaf+xml","mp3|m4a|m4b":"audio\/mpeg","aac":"audio\/aac","ra|ram":"audio\/x-realaudio","wav|x-wav":"audio\/wav","ogg|oga":"audio\/ogg","flac":"audio\/flac","mid|midi":"audio\/midi","wma":"audio\/x-ms-wma","wax":"audio\/x-ms-wax","mka":"audio\/x-matroska","rtf":"application\/rtf","pdf":"application\/pdf","class":"application\/java","tar":"application\/x-tar","zip":"application\/zip","gz|gzip":"application\/x-gzip","rar":"application\/rar","7z":"application\/x-7z-compressed","psd":"application\/octet-stream","xcf":"application\/octet-stream","doc":"application\/msword","pot|pps|ppt":"application\/vnd.ms-powerpoint","wri":"application\/vnd.ms-write","xla|xls|xlt|xlw":"application\/vnd.ms-excel","mdb":"application\/vnd.ms-access","mpp":"application\/vnd.ms-project","docx":"application\/vnd.openxmlformats-officedocument.wordprocessingml.document","docm":"application\/vnd.ms-word.document.macroEnabled.12","dotx":"application\/vnd.openxmlformats-officedocument.wordprocessingml.template","dotm":"application\/vnd.ms-word.template.macroEnabled.12","xlsx":"application\/vnd.openxmlformats-officedocument.spreadsheetml.sheet","xlsm":"application\/vnd.ms-excel.sheet.macroEnabled.12","xlsb":"application\/vnd.ms-excel.sheet.binary.macroEnabled.12","xltx":"application\/vnd.openxmlformats-officedocument.spreadsheetml.template","xltm":"application\/vnd.ms-excel.template.macroEnabled.12","xlam":"application\/vnd.ms-excel.addin.macroEnabled.12","pptx":"application\/vnd.openxmlformats-officedocument.presentationml.presentation","pptm":"application\/vnd.ms-powerpoint.presentation.macroEnabled.12","ppsx":"application\/vnd.openxmlformats-officedocument.presentationml.slideshow","ppsm":"application\/vnd.ms-powerpoint.slideshow.macroEnabled.12","potx":"application\/vnd.openxmlformats-officedocument.presentationml.template","potm":"application\/vnd.ms-powerpoint.template.macroEnabled.12","ppam":"application\/vnd.ms-powerpoint.addin.macroEnabled.12","sldx":"application\/vnd.openxmlformats-officedocument.presentationml.slide","sldm":"application\/vnd.ms-powerpoint.slide.macroEnabled.12","onetoc|onetoc2|onetmp|onepkg":"application\/onenote","oxps":"application\/oxps","xps":"application\/vnd.ms-xpsdocument","odt":"application\/vnd.oasis.opendocument.text","odp":"application\/vnd.oasis.opendocument.presentation","ods":"application\/vnd.oasis.opendocument.spreadsheet","odg":"application\/vnd.oasis.opendocument.graphics","odc":"application\/vnd.oasis.opendocument.chart","odb":"application\/vnd.oasis.opendocument.database","odf":"application\/vnd.oasis.opendocument.formula","wp|wpd":"application\/wordperfect","key":"application\/vnd.apple.keynote","numbers":"application\/vnd.apple.numbers","pages":"application\/vnd.apple.pages"},"select2L10n":{"matches_1":"One result is available, press enter to select it.","matches_n":"%d results are available, use up and down arrow keys to navigate.","matches_0":"No matches found","input_too_short_1":"Please enter 1 or more characters","input_too_short_n":"Please enter %d or more characters","input_too_long_1":"Please delete 1 character","input_too_long_n":"Please delete %d characters","selection_too_long_1":"You can only select 1 item","selection_too_long_n":"You can only select %d items","load_more":"Loading more results&hellip;","searching":"Searching&hellip;","load_fail":"Loading failed"},"google_map_api":"https:\/\/maps.googleapis.com\/maps\/api\/js?key=AIzaSyATXInOc90Znak88rk5wil1xct6NdGYgfM&libraries=places&ver=3&callback&language=en_US","datePickerL10n":{"closeText":"Done","currentText":"Today","nextText":"Next","prevText":"Prev","weekHeader":"Wk","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesMin":["S","M","T","W","T","F","S"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]},"dateTimePickerL10n":{"timeOnlyTitle":"Choose Time","timeText":"Time","hourText":"Hour","minuteText":"Minute","secondText":"Second","millisecText":"Millisecond","microsecText":"Microsecond","timezoneText":"Time Zone","currentText":"Now","closeText":"Done","selectText":"Select","amNames":["AM","A"],"pmNames":["PM","P"]}};
acf.l10n = [];
</script>
<script type="text/javascript">
acf.doAction('prepare');
</script>
	
<div class="wc-facebook-pixel-event-placeholder"></div><div class="widget_shopping_cart_live_region screen-reader-text" role="status"></div></body><!-- /body --></html>