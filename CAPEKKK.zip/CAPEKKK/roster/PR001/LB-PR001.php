<?php
$PageTitle or $pt = "Pussel Records";

$TanggalRilis or $tr = [
    "PR001" => "01 Oktober 2025",
    "PR002" => "15 Oktober 2025",
    "PR003" => "01 November 2025.",
    "PR004" => "13 November 2025",
    "PR005" => "25 November 2025",
    "PR006" => "17 Desember 2025",
    "PR007" => "2 pada Januari 2026",
    "PR008" => "18 Januari 2026",
    "PR009" => "10 Februari 2026",
    "PR010" => "COMING SOON"
];

$LookbookTitle or $lt = [
    "PR001" => "ENJOY DRINK - “RACHEL” EP",
    "PR002" => "FORESTS - “Get In Losers, We’re Going To Eternal Damnation”",
    "PR003" => "HEAVSIDE “After Glow” ALBUM",
    "PR004" => "PARAMEDIAN FOREHEAD FLAP “Not Really Matters” EP",
    "PR005" => "LEMON DJIN - “One By One I Face” ALBUM",
    "PR006" => "BEVERLYLINE - “As I Walk, Goodbye!” ALBUM",
    "PR007" => "MEOWNING - “These Memories Still Haunting” EP",
    "PR008" => "CARACAL - “Effigies”",
    "PR009" => "STARRDUCC “Chapter 3” EP",
    "PR010" => "AFTER HOURS “Stardust Diary” EP"
];

$Description or $desc = [
    "PR001" => "Band pop-punk/emo asal Indonesia, Enjoy Drink, resmi menandai langkah awal mereka di skena musik independen dengan merilis EP debut bertajuk “Rachel” pada tahun 2025. Mengusung semangat hardcore yang kental, rilisan ini menjadi pernyataan identitas Enjoy Drink jujur, emosional, dan penuh energi mentah",
    "PR002" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.",
    "PR003" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean",
    "PR004" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean",
    "PR005" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean
    massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.",
    "PR006" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean",
    "PR007" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean",
    "PR008" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean",
    "PR009" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean",
    "PR010" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Location &ndash; <?php echo $pt; ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="http://pusselrecords.my.id/img/logo/Logo-Icon-01.PNG">
    <link rel="shortcut icon" href="http://pusselrecords.my.id/img/logo/Logo-Icon-01.PNG">

    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@200..800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="../../css/index.css">
    <link rel="stylesheet" href="../../css/nav/header.css">
    <link rel="stylesheet" href="../../css/nav/footer.css">
    <link rel="stylesheet" href="../../css/root.css">
</head>
<body>

    <!-- container-fluid -->
    <div class="header-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="header-top-inner">
                        <div class="free-shipping-text">
                            <a href="../../index.php">
                                <img src="../http://pusselrecords.my.id/img/logo/Pussel Records-02.png" alt="Logo" class="img-fluid logo-img">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <div class="row header-logo-row">
                <div class="col-12 logo">
                    <a href="#">
                    </a>
                </div>
            </div>

            <div class="header-nav-wrapper">
                <div class="header-left">
                    <a href="../account/account.php" class="header-icon"><i class="bi bi-person"></i></a>
                </div>

                <!-- Nav-bar -->
                <nav class="menu">
                    <ul class="nav nav-menu">
                        <li class="nav-item"><a href="../../shop/shop.php" class="nav-link">Shop</a></li>
                        <li class="nav-item"><a href="../../location/location.php" class="nav-link">Store Location</a></li>
                        <li class="nav-item"><a href="../../lookbook/lookbook.php" class="nav-link">Lookbook</a></li>
                    </ul>
                </nav>

                <div class="header-right">
                    <a href="../../cart/cart.php" class="header-icon header-cart">
                        <i class="bi bi-bag"></i>
                        <span class="cart-badge">0</span>
                    </a>
                    <div class="hamburger-menu">
                        <i class="bi bi-list"></i>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section id="hero-section" class="hero-section">
        <div class="swiper hero-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="../http://pusselrecords.my.id/img/product/(PR001) ENJOY DRINK/cover.JPG" class="slide-img" alt="Slide 1">
                </div>
                <div class="swiper-slide">
                    <img src="../http://pusselrecords.my.id/img/product/(PR001) ENJOY DRINK/product.JPG" class="slide-img" alt="Slide 1">
                </div>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
    </section>






    <!-- Footer Section -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-5 footer-left">
                    <div class="footer-logo">
                        <ul>
                            <img src="../http://pusselrecords.my.id/img/logo/header-top.png" alt="Footer Logo" class="footer-logo-img">
                        </ul>
                    </div>
                    <div class="footer-contact">
                        <ul>
                            <p class="footer-contact-label">Our Location</p>
                            <p class="footer-contact-text">Jl. Elang Jawa No.5A, Nglarang, Wedomartani, Sleman, Yogyakarta
                                <br>Jl. Elang Jawa No.5A, Nglarang, Wedomartani, Sleman, Yogyakarta</p>
                            </p>
                        </ul>
                        <ul>
                            <p class="footer-contact-label">WA :</p>
                            <a href="#" class="footer-contact-link">(+60) 17 593 2909
                                <br>(+62) 851 2193 0348</a>
                        </ul>
                        <ul>
                            <p class="footer-contact-label">Email :</p>
                            <a href="mailto:pusselrecords@gmail.com" class="footer-contact-link">pusselrecords@gmail.com</a>     
                        </ul>
                    </div>
                </div>
                <div class="col-md-7 footer-right">
                    <div class="social-icons">
                        <a href="https://www.instagram.com/pusselrecords/" target="_blank" class="social-link"><i class="bi bi-instagram"></i></a>
                    </div>
                    <p class="footer-copy">© 2025, Pussel Records. All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="../../script.js"></script>
</body>
</html>