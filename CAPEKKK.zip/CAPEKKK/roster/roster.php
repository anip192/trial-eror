<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucwords(str_replace('.php', '', basename(__FILE__))); ?> &dash; Pussel Records</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../img/logo/Logo-Icon-01.PNG">
    <link rel="shortcut icon" href="../img/logo/Logo-Icon-01.PNG">

    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@200..800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="roster.css">

    <link rel="stylesheet" href="../css/root.css">
</head>
<body>

<link rel="stylesheet" href="../css/index.css">
<link rel="stylesheet" href="../css/root.css">
<link rel="stylesheet" href="../css/dplb.css">
<script src="../js/script.js"></script>

<?php include '../nav/nav/header.php'; ?>
<!-- MAIN CONTENT -->
<main class="lookbook-page">
    <div class="container">

        <!-- Page Title -->
        <div class="lookbook-header">
            <h1 class="lookbook-title">ROSTER</h1>
            <div class="lookbook-divider"></div>
        </div>

        <!-- Filter Tab (Opsional) -->
        <div class="lookbook-filter">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="comingsoon">COMING SOON</button>
            <button class="filter-btn" data-filter="newcomers">NEWCOMERS</button>
            <button class="filter-btn" data-filter="released">RELEASED</button>
        </div>

        <!-- Grid Lookbook -->
        <div class="lookbook-grid">

            <!-- Card 1 -->
            <div class="lookbook-card" data-year="comingsoon">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="../img/product/(PR001) ENJOY DRINK/cover.JPG" alt="Collection Vol.1" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">COLLECTION VOL.1</h3>
                        <p class="card-year">comingsoon</p>
                    </div>
                </a>
            </div>

            <!-- Card 2 -->
            <div class="lookbook-card" data-year="comingsoon">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="http://pusselrecords.my.id/img/product/(PR001) ENJOY DRINK/product.JPG" alt="Collection Vol.2" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">COLLECTION VOL.2</h3>
                        <p class="card-year">comingsoon</p>
                    </div>
                </a>
            </div>

            <!-- Card 3 -->
            <div class="lookbook-card" data-year="newcomers">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="http://pusselrecords.my.id/img/roster/look3.jpg" alt="SS25 Campaign" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">SS25 CAMPAIGN</h3>
                        <p class="card-year">newcomers</p>
                    </div>
                </a>
            </div>

            <!-- Card 4 -->
            <div class="lookbook-card" data-year="newcomers">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="http://pusselrecords.my.id/img/roster/look4.jpg" alt="FW25 Campaign" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">FW25 CAMPAIGN</h3>
                        <p class="card-year">newcomers</p>
                    </div>
                </a>
            </div>

            <!-- Card 5 -->
            <div class="lookbook-card" data-year="released">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="http://pusselrecords.my.id/img/roster/look5.jpg" alt="Archive released" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">ARCHIVE released</h3>
                        <p class="card-year">released</p>
                    </div>
                </a>
            </div>

            <!-- Card 6 -->
            <div class="lookbook-card" data-year="released">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="http://pusselrecords.my.id/img/roster/look6.jpg" alt="Debut Series" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">DEBUT SERIES</h3>
                        <p class="card-year">released</p>
                    </div>
                </a>
            </div>

        </div>
        <!-- /lookbook-grid -->

    </div>
</main>

<?php include '../nav/nav/footer.php'; ?>
<script src="http://pusselrecords.my.id/roster/roster.js"></script>
</body>
</html>