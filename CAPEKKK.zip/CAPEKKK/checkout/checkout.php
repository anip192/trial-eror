<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart &ndash; <?php echo $pt; ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="http://pusselrecords.my.id/img/logo/Logo-Icon-01.PNG">
    <link rel="shortcut icon" href="http://pusselrecords.my.id/img/logo/Logo-Icon-01.PNG">

    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@200..800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="../css/nav/header.css">
    <link rel="stylesheet" href="../css/nav/footer.css">
    <link rel="stylesheet" href="../css/root.css">
</head>
<body>

    <!-- container-fluid -->
    <div class="header-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="header-top-inner">
                        <div class="free-shipping-text">
                            <a href="../index.php">
                                <img src="/img/logo/Pussel Records-02.png" alt="Logo" class="img-fluid logo-img">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <div class="row header-logo-row">
                <div class="col-12 logo">
                    <a href="#">
                    </a>
                </div>
            </div>

            <div class="header-nav-wrapper">
                <div class="header-left">
                    <a href="../account/account.php" class="header-icon"><i class="bi bi-person"></i></a>
                </div>

                <!-- Nav-bar -->
                <nav class="menu">
                    <ul class="nav nav-menu">
                        <li class="nav-item"><a href="../shop/shop.php" class="nav-link">Shop</a></li>
                        <li class="nav-item"><a href="../location/location.php" class="nav-link">Store Location</a></li>
                        <li class="nav-item"><a href="../lookbook/lookbook.php" class="nav-link">Lookbook</a></li>
                    </ul>
                </nav>

                <div class="header-right">
                    <a href="../cart/cart.php" class="header-icon header-cart">
                        <i class="bi bi-bag"></i>
                        <span class="cart-badge">0</span>
                    </a>
                    <div class="hamburger-menu">
                        <i class="bi bi-list"></i>
                    </div>
                </div>
            </div>
        </div>
    </header>






    <!-- Footer Section -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-5 footer-left">
                    <div class="footer-logo">
                        <ul>
                            <img src="http://pusselrecords.my.id/img/logo/header-top.png" alt="Footer Logo" class="footer-logo-img">
                        </ul>
                    </div>
                    <div class="footer-contact">
                        <ul>
                            <p class="footer-contact-label">Our Location</p>
                            <p class="footer-contact-text">Jl. Elang Jawa No.5A, Nglarang, Wedomartani, Sleman, Yogyakarta
                                <br>Jl. Elang Jawa No.5A, Nglarang, Wedomartani, Sleman, Yogyakarta</p>
                            </p>
                        </ul>
                        <ul>
                            <p class="footer-contact-label">WA :</p>
                            <a href="#" class="footer-contact-link">(+60) 17 593 2909
                                <br>(+62) 851 2193 0348</a>
                        </ul>
                        <ul>
                            <p class="footer-contact-label">Email :</p>
                            <a href="mailto:pusselrecords@gmail.com" class="footer-contact-link">pusselrecords@gmail.com</a>     
                        </ul>
                    </div>
                </div>
                <div class="col-md-7 footer-right">
                    <div class="social-icons">
                        <a href="https://www.instagram.com/pusselrecords/" target="_blank" class="social-link"><i class="bi bi-instagram"></i></a>
                    </div>
                    <p class="footer-copy">© 2025, Pussel Records. All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </footer>

</body>
</html>