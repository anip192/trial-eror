<link rel="stylesheet" href="../css/index.css">
<link rel="stylesheet" href="../css/root.css">
<link rel="stylesheet" href="../css/dplb.css">
<script src="script.js"></script>

<?php include 'nav/header.php'; ?>
<!-- MAIN CONTENT -->
<main class="lookbook-page">
    <div class="container">

        <!-- Page Title -->
        <div class="lookbook-header">
            <h1 class="lookbook-title">ROSTER</h1>
            <div class="lookbook-divider"></div>
        </div>

        <!-- Filter Tab (Opsional) -->
        <div class="lookbook-filter">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="comingsoon">COMING SOON</button>
            <button class="filter-btn" data-filter="newcomers">NEWCOMERS</button>
            <button class="filter-btn" data-filter="released">RELEASED</button>
        </div>

        <!-- Grid Lookbook -->
        <div class="lookbook-grid">

            <!-- Card 1 -->
            <div class="lookbook-card" data-year="comingsoon">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="../img/product/(PR001) ENJOY DRINK/cover.JPG" alt="Collection Vol.1" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">COLLECTION VOL.1</h3>
                        <p class="card-year">comingsoon</p>
                    </div>
                </a>
            </div>

            <!-- Card 2 -->
            <div class="lookbook-card" data-year="comingsoon">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="../img/product/(PR001) ENJOY DRINK/product.JPG" alt="Collection Vol.2" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">COLLECTION VOL.2</h3>
                        <p class="card-year">comingsoon</p>
                    </div>
                </a>
            </div>

            <!-- Card 3 -->
            <div class="lookbook-card" data-year="newcomers">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="../img/lookbook/look3.jpg" alt="SS25 Campaign" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">SS25 CAMPAIGN</h3>
                        <p class="card-year">newcomers</p>
                    </div>
                </a>
            </div>

            <!-- Card 4 -->
            <div class="lookbook-card" data-year="newcomers">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="../img/lookbook/look4.jpg" alt="FW25 Campaign" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">FW25 CAMPAIGN</h3>
                        <p class="card-year">newcomers</p>
                    </div>
                </a>
            </div>

            <!-- Card 5 -->
            <div class="lookbook-card" data-year="released">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="../img/lookbook/look5.jpg" alt="Archive released" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">ARCHIVE released</h3>
                        <p class="card-year">released</p>
                    </div>
                </a>
            </div>

            <!-- Card 6 -->
            <div class="lookbook-card" data-year="released">
                <a href="#" class="card-link">
                    <div class="card-img-wrap">
                        <img src="../img/lookbook/look6.jpg" alt="Debut Series" loading="lazy">
                        <div class="card-overlay">
                            <span class="overlay-text">View</span>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3 class="card-title">DEBUT SERIES</h3>
                        <p class="card-year">released</p>
                    </div>
                </a>
            </div>

        </div>
        <!-- /lookbook-grid -->

    </div>
</main>

<?php include 'footer.php'; ?>

<style>
/* ============================================
   LOOKBOOK PAGE CSS
   Referensi: Disaster Records Roster Style
   Monokrom, no sidebar, full-width grid
   ============================================ */

/* ---- PAGE WRAPPER ---- */
.lookbook-page {
    padding: 3rem 0 5rem;
    background: #fff;
    min-height: 60vh;
}

/* ---- PAGE HEADER ---- */
.lookbook-header {
    margin-bottom: 1.5rem;
}

.lookbook-title {
    text-transform: uppercase;
    font-size: 2.5rem;
    font-weight: 700;
    margin: 0;
}

.lookbook-divider {
    height: 1px;
    width: 100%;
    margin-bottom: 2rem;
}

/* ---- FILTER BUTTONS ---- */
.lookbook-filter {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 2.5rem;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 0.4rem 1.2rem;
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    border: 1.5px solid #0f0f0f;
    background: transparent;
    color: #0f0f0f;
    cursor: pointer;
    border-radius: 2px;
    transition: all 0.2s ease;
    font-family: 'Poppins', sans-serif;
}

.filter-btn:hover,
.filter-btn.active {
    background: #0f0f0f;
    color: #fff;
}

/* ---- GRID ---- */
.lookbook-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 0; /* rapet seperti referensi */
}

/* ---- CARD ---- */
.lookbook-card {
    position: relative;
    overflow: hidden;
    border: 1px solid #f0f0f0;
}

.card-link {
    text-decoration: none;
    display: block;
    color: inherit;
}

/* Gambar */
.card-img-wrap {
    position: relative;
    overflow: hidden;
    aspect-ratio: 3 / 4; /* portrait seperti referensi */
    background: #e0e0e0;
}

.card-img-wrap img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    filter: grayscale(100%); /* hitam putih seperti referensi */
    transition: transform 0.5s ease, filter 0.4s ease;
}

.lookbook-card:hover .card-img-wrap img {
    transform: scale(1.04);
    filter: grayscale(60%);
}

/* Overlay hover */
.card-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.lookbook-card:hover .card-overlay {
    opacity: 1;
}

.overlay-text {
    color: #fff;
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 4px;
    text-transform: uppercase;
    border: 1.5px solid #fff;
    padding: 0.5rem 1.5rem;
    font-family: 'Poppins', sans-serif;
}

/* Info bawah card */
.card-info {
    padding: 1rem 0.5rem;
    border-top: 1px solid #dee2e6;
}

.card-title {
    font-family: 'Bebas Neue', 'Poppins', sans-serif;
    font-size: 1.1rem;
    font-weight: 900;
    letter-spacing: 3px;
    color: #0f0f0f;
    margin: 0 0 0.2rem;
    text-transform: uppercase;
}

.card-year {
    font-size: 0.78rem;
    color: #999;
    letter-spacing: 1px;
    margin: 0;
}

/* ============================================
   RESPONSIVE
   ============================================ */
@media (max-width: 992px) {
    .lookbook-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 576px) {
    .lookbook-grid { grid-template-columns: repeat(1, 1fr); }
    .lookbook-title { font-size: 2rem; }
}
</style>

<script>
// Filter Lookbook by Year
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        // Update active button
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');

        const filter = this.dataset.filter;
        document.querySelectorAll('.lookbook-card').forEach(card => {
            if (filter === 'all' || card.dataset.year === filter) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
});
</script>
